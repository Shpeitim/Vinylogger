@echo off
taskkill /im "Vinylogger.exe" /f >nul 2>nul
rmdir /s /q "%LOCALAPPDATA%\Programs\Vinylogger" 2>nul
powershell -NoProfile -Command "foreach($d in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ Remove-Item (Join-Path $d 'Vinylogger.lnk') -ErrorAction SilentlyContinue }"
echo Vinylogger has been removed. Your data in %LOCALAPPDATA%\vinylogger was kept.
pause
