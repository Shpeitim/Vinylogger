# Entry point for the Windows .exe (PyInstaller)
from vinylogger.app import main

main()
