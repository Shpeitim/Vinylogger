@echo off
setlocal
title Vinylogger - Setup
cd /d "%~dp0\.."

echo ==^> Building Vinylogger for Windows.
echo     The first run takes a few minutes.
echo.

where uv >nul 2>nul
if errorlevel 1 (
    echo ==^> Installing uv, the Python tool by Astral ...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    set "PATH=%USERPROFILE%\.local\bin;%PATH%"
)
where uv >nul 2>nul
if errorlevel 1 (
    echo uv could not be installed. Please close this window, open it again and retry.
    goto fail
)

echo ==^> Downloading Python and libraries ...
uv sync
if errorlevel 1 goto fail

echo ==^> Building "Vinylogger.exe" ...
uv run --with pyinstaller pyinstaller --noconfirm --clean --windowed ^
    --name "Vinylogger" --icon "%CD%\windows\icon.ico" ^
    --add-data "%CD%\vinylogger\icon.svg;vinylogger" ^
    --collect-submodules keyring --copy-metadata keyring ^
    --distpath build-win\dist --workpath build-win\work --specpath build-win ^
    "%CD%\windows\start.py"
if errorlevel 1 goto fail

set "DEST=%LOCALAPPDATA%\Programs\Vinylogger"

rem Before 1.3 the app was called "Vinyl Scrobbler" - remove that install (data is kept and imported)
taskkill /im "Vinyl Scrobbler.exe" /f >nul 2>nul
if exist "%LOCALAPPDATA%\Programs\Vinyl Scrobbler" rmdir /s /q "%LOCALAPPDATA%\Programs\Vinyl Scrobbler"
powershell -NoProfile -Command "foreach($d in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ Remove-Item (Join-Path $d 'Vinyl Scrobbler.lnk') -ErrorAction SilentlyContinue }"
echo ==^> Installing to %DEST% ...
taskkill /im "Vinylogger.exe" /f >nul 2>nul
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy /e /i /q /y "build-win\dist\Vinylogger" "%DEST%" >nul
if errorlevel 1 goto fail

echo ==^> Creating shortcuts in the Start menu and on the desktop ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ $s=$w.CreateShortcut((Join-Path $d 'Vinylogger.lnk')); $s.TargetPath='%DEST%\Vinylogger.exe'; $s.WorkingDirectory='%DEST%'; $s.Save() }"

rmdir /s /q build-win >nul 2>nul
echo.
echo Done! You will find "Vinylogger" in the Start menu and on your desktop.
pause
exit /b 0

:fail
echo.
echo *** Something went wrong. Please copy the messages above. ***
pause
exit /b 1
