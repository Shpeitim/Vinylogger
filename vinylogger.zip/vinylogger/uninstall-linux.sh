#!/usr/bin/env bash
# Removes Vinylogger (both the Arch package and the home-folder install).
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"

if command -v pacman >/dev/null 2>&1 && pacman -Q vinylogger >/dev/null 2>&1; then
    echo "==> Removing the pacman package (you may be asked for your password) ..."
    sudo pacman -R --noconfirm vinylogger
fi

# also clean up the old name ("Vinyl Scrobbler", before 1.3)
OLD="vinyl""scrobbler"
if command -v pacman >/dev/null 2>&1 && pacman -Q "$OLD" >/dev/null 2>&1; then
    sudo pacman -R --noconfirm "$OLD"
fi
rm -rf "$DATA/$OLD-app"
rm -f "$HOME/.local/bin/$OLD" "$DATA/applications/$OLD.desktop" "$DATA/icons/hicolor/scalable/apps/$OLD.svg"

rm -rf "$DATA/vinylogger-app"
rm -f "$HOME/.local/bin/vinylogger" \
      "$DATA/applications/vinylogger.desktop" \
      "$DATA/icons/hicolor/scalable/apps/vinylogger.svg"
update-desktop-database "$DATA/applications" >/dev/null 2>&1 || true
kbuildsycoca6 >/dev/null 2>&1 || kbuildsycoca5 >/dev/null 2>&1 || true

echo "Vinylogger has been removed."
echo
echo "Your settings and history were kept. To delete them too:"
echo "    rm -rf ~/.config/vinylogger ~/.local/share/vinylogger"
echo "Leftovers from the old name can go too:"
echo "    rm -rf ~/.config/vinyl""scrobbler ~/.local/share/vinyl""scrobbler"
echo "Your Discogs/Last.fm credentials are stored in your keyring (e.g. KWallet) under \"vinylogger\"."
