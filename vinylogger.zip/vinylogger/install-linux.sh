#!/usr/bin/env bash
# Installs (or updates) Vinylogger on Linux.
#
#   Arch / CachyOS / Manjaro / EndeavourOS:
#       builds a native pacman package (uses the system Qt, so it matches your theme)
#   All other distributions (Ubuntu, Debian, Mint, Pop!_OS, Fedora, openSUSE, ...):
#       installs into your home folder using uv – no system Python packages needed
#
#   Force the home-folder method on Arch:   ./install-linux.sh --generic
#   Uninstall:                              ./uninstall-linux.sh
set -e
cd "$(dirname "$(readlink -f "$0")")"
SRC="$(pwd)"
VER="$(sed -n 's/^__version__ = "\(.*\)"/\1/p' vinylogger/__init__.py)"

if [ "$(id -u)" = "0" ]; then
    echo "Please do NOT run this with sudo. Just run:  ./install-linux.sh"
    exit 1
fi

DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
APPDIR="$DATA/vinylogger-app"
BINDIR="$HOME/.local/bin"

# Before version 1.3 the app was called "Vinyl Scrobbler" – remove that install so it isn't listed twice.
remove_old_name() {
    local old="vinyl""scrobbler"
    if command -v pacman >/dev/null 2>&1 && pacman -Q "$old" >/dev/null 2>&1; then
        echo "==> Removing the old \"Vinyl Scrobbler\" package (your data is kept and imported) ..."
        sudo pacman -R --noconfirm "$old"
    fi
    rm -rf "$DATA/$old-app"
    rm -f "$BINDIR/$old" "$DATA/applications/$old.desktop" "$DATA/icons/hicolor/scalable/apps/$old.svg"
}

refresh_menu() {
    update-desktop-database "$DATA/applications" >/dev/null 2>&1 || true
    gtk-update-icon-cache -q "$DATA/icons/hicolor" >/dev/null 2>&1 || true
    kbuildsycoca6 >/dev/null 2>&1 || kbuildsycoca5 >/dev/null 2>&1 || true
}

# ---------------------------------------------------------------- Arch: native package
install_arch() {
    echo "==> Arch-based system detected – building a native package (Vinylogger $VER)"
    echo "    (You'll be asked for your password for pacman.)"
    sudo pacman -S --needed --noconfirm base-devel
    remove_old_name

    # remove a previous home-folder install so the menu doesn't show two entries
    rm -rf "$APPDIR" "$BINDIR/vinylogger" \
           "$DATA/applications/vinylogger.desktop" "$DATA/icons/hicolor/scalable/apps/vinylogger.svg"

    rm -rf build-arch
    mkdir build-arch
    cp arch/PKGBUILD build-arch/
    sed -i "s/^pkgver=.*/pkgver=$VER/" build-arch/PKGBUILD
    tar --exclude='__pycache__' -czf "build-arch/vinylogger-$VER.tar.gz" \
        --transform "s,^,vinylogger-$VER/," vinylogger vinylogger.desktop
    (cd build-arch && makepkg -si --noconfirm --needed)
    rm -rf build-arch
    refresh_menu
}

# ---------------------------------------------------------------- everything else: home folder
have_lib() {
    { ldconfig -p 2>/dev/null || /sbin/ldconfig -p 2>/dev/null; } | grep -q "$1"
}

install_system_libs() {
    # Qt needs a few small X11 libraries that aren't always preinstalled.
    if have_lib "libxcb-cursor.so.0" && have_lib "libxkbcommon-x11.so.0"; then
        return
    fi
    echo "==> Installing a few small system libraries Qt needs (you may be asked for your password) ..."
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get install -y libxcb-cursor0 libxkbcommon-x11-0 libegl1
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y xcb-util-cursor libxkbcommon-x11
    elif command -v zypper >/dev/null 2>&1; then
        sudo zypper --non-interactive install libxcb-cursor0 libxkbcommon-x11-0
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -S --needed --noconfirm xcb-util-cursor libxkbcommon-x11
    else
        echo "    Unknown package manager – if the app doesn't start, install 'libxcb-cursor' manually."
    fi
}

find_uv() {
    if command -v uv >/dev/null 2>&1; then
        command -v uv
    elif [ -x "$HOME/.local/bin/uv" ]; then
        echo "$HOME/.local/bin/uv"
    fi
}

install_generic() {
    echo "==> Installing Vinylogger $VER into your home folder"
    remove_old_name
    install_system_libs

    UV="$(find_uv)"
    if [ -z "$UV" ]; then
        echo "==> Installing uv (Python tool by Astral) ..."
        if command -v curl >/dev/null 2>&1; then
            curl -LsSf https://astral.sh/uv/install.sh | env UV_NO_MODIFY_PATH=1 sh
        elif command -v wget >/dev/null 2>&1; then
            wget -qO- https://astral.sh/uv/install.sh | env UV_NO_MODIFY_PATH=1 sh
        else
            echo "Please install 'curl' first (e.g. sudo apt install curl) and run this script again."
            exit 1
        fi
        UV="$HOME/.local/bin/uv"
    fi

    echo "==> Setting up Python and libraries (first run takes a few minutes, Qt is big) ..."
    rm -rf "$APPDIR"
    mkdir -p "$APPDIR" "$BINDIR"
    "$UV" venv --quiet --python 3.12 "$APPDIR/venv"
    "$UV" pip install --quiet --python "$APPDIR/venv/bin/python" "$SRC"

    ln -sf "$APPDIR/venv/bin/vinylogger" "$BINDIR/vinylogger"

    echo "==> Adding Vinylogger to your application menu ..."
    mkdir -p "$DATA/applications" "$DATA/icons/hicolor/scalable/apps"
    cp vinylogger/icon.svg "$DATA/icons/hicolor/scalable/apps/vinylogger.svg"
    sed "s|^Exec=.*|Exec=\"$APPDIR/venv/bin/vinylogger\"|" vinylogger.desktop \
        > "$DATA/applications/vinylogger.desktop"
    refresh_menu

    case ":$PATH:" in
        *":$BINDIR:"*) ;;
        *) echo "    Note: $BINDIR is not in your PATH – the menu entry works anyway." ;;
    esac
}

# ---------------------------------------------------------------- go
if [ "$1" != "--generic" ] && command -v pacman >/dev/null 2>&1 && command -v makepkg >/dev/null 2>&1; then
    install_arch
else
    install_generic
fi

echo
echo "Done! \"Vinylogger\" is now in your application menu."
echo "You can delete this download folder now – your settings and history are kept separately."
