# Vinylogger

_Früher hieß die App „Vinyl Scrobbler“. Beim Update werden Einstellungen, Verlauf und Anmeldungen automatisch übernommen._

Platte aus der Discogs-Sammlung auswählen → abspielen → bei Last.fm scrobbeln.

## Installation

### Linux (jede Distribution)
1. Ordner entpacken, im Dateimanager öffnen, Terminal öffnen (in Dolphin: **F4**).
2. `./install-linux.sh` ausführen (als normaler Benutzer, nicht mit sudo – das Passwort wird bei Bedarf abgefragt).
   - Arch, CachyOS, Manjaro, EndeavourOS: Es wird ein echtes pacman-Paket gebaut.
   - Ubuntu, Debian, Mint, Fedora, openSUSE usw.: Die App wird in deinen Home-Ordner installiert.
3. „Vinylogger“ im Startmenü starten. Den Download-Ordner kannst du danach löschen.

Update: neue Version entpacken, Skript nochmal ausführen.
Entfernen: `./uninstall-linux.sh`

### Windows 10/11
1. Ordner entpacken.
2. Im Unterordner `windows` doppelt auf **install-windows.bat** klicken.
   (Falls Windows „Der Computer wurde durch Windows geschützt“ zeigt: „Weitere Informationen“ → „Trotzdem ausführen“.)
3. „Vinylogger“ im Startmenü oder auf dem Desktop starten.

Entfernen: `windows\uninstall-windows.bat`

## Sprache
Die App startet auf Englisch. Auf Deutsch umstellen: **Settings …** → **Language / Sprache** → **Deutsch** → „Restart now“.
Die Knopf-Namen unten beziehen sich auf die deutsche Oberfläche.

## Konten einrichten (einmalig, in der App unter „Einstellungen …“)

**Discogs:** „Token holen …“ → auf discogs.com „Generate new token“ → Token kopieren → einfügen → „Verbinden“.

**Last.fm:** „API-Konto erstellen …“ → Application name z. B. „Vinylogger“ → absenden →
API key und Shared secret kopieren → einfügen → „Bei Last.fm anmelden“ → im Browser „Yes, allow access“ → in der App OK.

Zugangsdaten liegen unter Linux in KWallet (Secret Service), unter Windows in der Anmeldeinformationsverwaltung.

## Benutzung
- **Jetzt anhören:** Läuft im Takt der Tracklist mit, sendet „Now Playing“ und scrobbelt jeden Track, wenn er vorbei ist.
  Beim Seitenwechsel hält die App an – Platte umdrehen, dann „▶ Weiter“.
  „Nächster“ springt weiter (Track wird nur gescrobbelt, wenn die Hälfte bzw. 4 Minuten gelaufen sind).
- **Schon gehört …:** Ausgewählte Tracks nachträglich scrobbeln („gerade zu Ende“ oder mit Startzeit, max. 14 Tage zurück).
- Häkchen bzw. „Seite A/B …“ bestimmen, welche Tracks zählen. Fehlende Längen („~3:30“) per Doppelklick korrigieren – die App merkt sich das.
- Ohne Internet werden Scrobbles gespeichert und später automatisch nachgesendet (Tab „Verlauf“).

## Wo liegen meine Daten?
- Linux: `~/.config/vinylogger/` und `~/.local/share/vinylogger/`
- Windows: `%APPDATA%\vinylogger\` und `%LOCALAPPDATA%\vinylogger\`
