"""Local database: collection cache, tracklist cache, own lengths, scrobble history."""
from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass

from .discogs import Album
from .lastfm import Scrobble
from .paths import data_dir

DB_FILE = data_dir() / "vinylogger.sqlite"

SENT, PENDING, REJECTED = "gesendet", "ausstehend", "abgelehnt"


@dataclass
class LogEntry:
    id: int
    scrobble: Scrobble
    release_id: int | None
    status: str
    message: str


class Store:
    def __init__(self, path=DB_FILE):
        self.db = sqlite3.connect(path)
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS albums (instance_id INTEGER PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS releases (release_id INTEGER PRIMARY KEY, data TEXT NOT NULL,
                                                 fetched_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS durations (release_id INTEGER, position TEXT, seconds INTEGER,
                                                  PRIMARY KEY (release_id, position));
            CREATE TABLE IF NOT EXISTS scrobbles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL, artist TEXT NOT NULL, track TEXT NOT NULL,
                album TEXT, album_artist TEXT, duration INTEGER, release_id INTEGER,
                status TEXT NOT NULL, message TEXT DEFAULT '');
            CREATE INDEX IF NOT EXISTS idx_scrobbles_ts ON scrobbles(ts);
        """)
        self.db.commit()

    # ------------------------------------------------------------ Sammlung
    def save_collection(self, albums: list[Album]) -> None:
        with self.db:
            self.db.execute("DELETE FROM albums")
            self.db.executemany("INSERT OR REPLACE INTO albums VALUES (?,?)",
                                [(a.instance_id or a.release_id, json.dumps(a.to_dict())) for a in albums])

    def load_collection(self) -> list[Album]:
        out = []
        for (data,) in self.db.execute("SELECT data FROM albums"):
            try:
                out.append(Album(**json.loads(data)))
            except (TypeError, ValueError):
                pass
        return out

    # ------------------------------------------------------------ Releases
    def get_release(self, release_id: int) -> dict | None:
        row = self.db.execute("SELECT data FROM releases WHERE release_id=?", (release_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_release(self, release_id: int, data: dict) -> None:
        keep = {k: data.get(k) for k in ("id", "title", "artists", "tracklist", "year", "images")}
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO releases VALUES (?,?,?)",
                            (release_id, json.dumps(keep), int(time.time())))

    def durations(self, release_id: int) -> dict[str, int]:
        return dict(self.db.execute("SELECT position, seconds FROM durations WHERE release_id=?",
                                    (release_id,)).fetchall())

    def set_duration(self, release_id: int, position: str, seconds: int | None) -> None:
        with self.db:
            if seconds:
                self.db.execute("INSERT OR REPLACE INTO durations VALUES (?,?,?)",
                                (release_id, position, seconds))
            else:
                self.db.execute("DELETE FROM durations WHERE release_id=? AND position=?",
                                (release_id, position))

    # ------------------------------------------------------------ Scrobble-Verlauf
    def add_scrobbles(self, items: list[Scrobble], release_id: int | None) -> list[int]:
        ids = []
        with self.db:
            for s in items:
                cur = self.db.execute(
                    "INSERT INTO scrobbles (ts, artist, track, album, album_artist, duration, release_id, status)"
                    " VALUES (?,?,?,?,?,?,?,?)",
                    (s.timestamp, s.artist, s.track, s.album, s.album_artist, s.duration, release_id, PENDING))
                ids.append(int(cur.lastrowid))
        return ids

    def set_status(self, log_id: int, status: str, message: str = "") -> None:
        with self.db:
            self.db.execute("UPDATE scrobbles SET status=?, message=? WHERE id=?", (status, message, log_id))

    def _rows(self, where: str, args: tuple, limit: int) -> list[LogEntry]:
        rows = self.db.execute(
            "SELECT id, ts, artist, track, album, album_artist, duration, release_id, status, message"
            f" FROM scrobbles {where} ORDER BY ts DESC LIMIT ?", (*args, limit)).fetchall()
        return [LogEntry(r[0], Scrobble(r[2], r[3], r[1], r[4], r[5], r[6]), r[7], r[8], r[9] or "")
                for r in rows]

    def recent(self, limit: int = 1000) -> list[LogEntry]:
        return self._rows("", (), limit)

    def pending(self) -> list[LogEntry]:
        return self._rows("WHERE status=?", (PENDING,), 500)

    def delete(self, log_id: int) -> None:
        with self.db:
            self.db.execute("DELETE FROM scrobbles WHERE id=?", (log_id,))

    def close(self) -> None:
        self.db.close()
