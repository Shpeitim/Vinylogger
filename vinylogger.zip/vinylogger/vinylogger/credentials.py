"""Store credentials securely.

Linux:   via Secret Service (KDE: KWallet, GNOME: GNOME Keyring)
Windows: Windows Credential Manager
If neither is available they go into a file only your user can read –
that is NOT encrypted, and the app tells you so.
"""
from __future__ import annotations

import json
import os

from .i18n import _
from .paths import config_dir

SERVICE = "vinylogger"
FALLBACK_FILE = config_dir() / "zugangsdaten.json"


class Credentials:
    def __init__(self) -> None:
        self._kr = None
        self.backend = _("File (not encrypted)")
        try:
            import keyring
            from keyring.backends import fail

            if os.name == "nt":
                from keyring.backends import Windows
                keyring.set_keyring(Windows.WinVaultKeyring())
            kr = keyring.get_keyring()
            if not isinstance(kr, fail.Keyring):
                self._kr = keyring
                inner = getattr(kr, "backends", None)  # ChainerBackend -> erstes echtes Backend
                name = type(inner[0]).__name__ if inner else type(kr).__name__
                self.backend = {
                    "WinVaultKeyring": _("Windows Credential Manager"),
                    "DBusKeyring": "KWallet",
                    "Keyring": _("Secret Service (KWallet / GNOME Keyring)"),
                }.get(name, name)
        except Exception:  # noqa: BLE001
            self._kr = None

    @property
    def secure(self) -> bool:
        return self._kr is not None

    # ------------------------------------------------------------ file fallback
    def _file_load(self) -> dict:
        try:
            return json.loads(FALLBACK_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _file_save(self, data: dict) -> None:
        FALLBACK_FILE.write_text(json.dumps(data), encoding="utf-8")
        try:
            os.chmod(FALLBACK_FILE, 0o600)
        except OSError:
            pass

    def _fallback(self) -> None:
        self._kr = None
        self.backend = _("File (not encrypted)")

    # ------------------------------------------------------------ public
    def get(self, key: str) -> str | None:
        if self._kr:
            try:
                return self._kr.get_password(SERVICE, key)
            except Exception:  # noqa: BLE001  z. B. Wallet gesperrt / Dienst weg
                self._fallback()
        return self._file_load().get(key)

    def set(self, key: str, value: str | None) -> None:
        if self._kr:
            try:
                if value:
                    self._kr.set_password(SERVICE, key, value)
                else:
                    try:
                        self._kr.delete_password(SERVICE, key)
                    except Exception:  # noqa: BLE001  wasn't stored
                        pass
                return
            except Exception:  # noqa: BLE001
                self._fallback()
        data = self._file_load()
        if value:
            data[key] = value
        else:
            data.pop(key, None)
        self._file_save(data)
