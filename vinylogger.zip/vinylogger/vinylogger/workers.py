"""Run work in the background so the UI doesn’t freeze."""
from __future__ import annotations

import traceback

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal

_alive: set = set()


class _Signals(QObject):
    done = Signal(object)
    failed = Signal(object)
    progress = Signal(object)


class _Job(QRunnable):
    def __init__(self, fn, args, kwargs, sig: _Signals):
        super().__init__()
        self.fn, self.args, self.kwargs, self.sig = fn, args, kwargs, sig

    def run(self) -> None:
        try:
            result = self.fn(*self.args, **self.kwargs)
        except Exception as e:  # noqa: BLE001
            e.trace = traceback.format_exc()  # type: ignore[attr-defined]
            self.sig.failed.emit(e)
        else:
            self.sig.done.emit(result)


def run_bg(fn, *args, on_done=None, on_error=None, on_progress=None, pool: QThreadPool | None = None, **kwargs):
    """Run fn(*args, **kwargs) in the background. If on_progress is set, fn receives progress=..."""
    sig = _Signals()
    _alive.add(sig)

    def finish(*_):
        _alive.discard(sig)

    if on_done:
        sig.done.connect(on_done)
    if on_error:
        sig.failed.connect(on_error)
    if on_progress:
        sig.progress.connect(on_progress)
        kwargs["progress"] = sig.progress.emit
    sig.done.connect(finish)
    sig.failed.connect(finish)
    (pool or QThreadPool.globalInstance()).start(_Job(fn, args, kwargs, sig))
