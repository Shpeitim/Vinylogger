"""Simple translations. English is the source language; German lives in DE below.

Usage:  _("Hello {name}", name="Shpeitim")
"""
from __future__ import annotations

from datetime import datetime

LANGUAGES = [("en", "English"), ("de", "Deutsch")]
_lang = "en"


def set_language(code: str) -> None:
    global _lang
    _lang = code if code in dict(LANGUAGES) else "en"


def language() -> str:
    return _lang


def _(text: str, **kw) -> str:
    if _lang == "de":
        text = DE.get(text, text)
    return text.format(**kw) if kw else text


def fmt_dt(dt: datetime, short: bool = False) -> str:
    if _lang == "de":
        return dt.strftime("%d.%m. %H:%M" if short else "%d.%m.%Y %H:%M")
    return dt.strftime("%b %d, %H:%M" if short else "%Y-%m-%d %H:%M")


def qt_datetime_format() -> str:
    return "dd.MM.yyyy  HH:mm" if _lang == "de" else "yyyy-MM-dd  HH:mm"


DE: dict[str, str] = {
    ", {n} rejected (see History)":
        ", {n} abgelehnt (siehe Verlauf)",
    "1. Click “Get token …” – the Discogs developer settings open in your browser.<br>2. Click <b>“Generate new token”</b> there and copy the token.<br>3. Paste it here and click <b>Connect</b>.":
        "1. Klicke auf „Token holen …“ – die Discogs-Entwickler-Einstellungen öffnen sich im Browser.<br>2. Klicke dort auf <b>„Generate new token“</b> und kopiere den Token.<br>3. Füge ihn hier ein und klicke auf <b>Verbinden</b>.",
    "1. Create a free API account (button “Create API account …”). Enter e.g. <i>Vinylogger</i> as “Application name”, you can leave the other fields empty.<br>2. Copy the <b>API key</b> and <b>Shared secret</b> here.<br>3. Click <b>Log in to Last.fm</b> and allow access in your browser.":
        "1. Erstelle ein kostenloses API-Konto (Knopf „API-Konto erstellen …“). Bei „Application name“ z. B. <i>Vinylogger</i> eintragen, die übrigen Felder kannst du leer lassen.<br>2. Kopiere <b>API key</b> und <b>Shared secret</b> hierher.<br>3. Klicke auf <b>Bei Last.fm anmelden</b> und erlaube den Zugriff im Browser.",
    "<b>{album}</b><br>{n} tracks, {length} in total":
        "<b>{album}</b><br>{n} Tracks, zusammen {length}",
    "A record is playing in live mode. Quit anyway?\n\nThe current track will be scrobbled if it has played long enough.":
        "Es läuft gerade eine Platte im Live-Modus. Trotzdem beenden?\n\nDer aktuelle Track wird gescrobbelt, wenn er schon lange genug lief.",
    "API key:":
        "API key:",
    "Access hasn’t been allowed in the browser yet. Please try again.":
        "Der Zugriff wurde im Browser noch nicht erlaubt. Bitte nochmal versuchen.",
    "Album":
        "Album",
    "All":
        "Alle",
    "Already listened – scrobble afterwards":
        "Schon gehört – nachträglich scrobbeln",
    "Already playing":
        "Läuft schon",
    "Another record is playing right now. Stop it and start this one?":
        "Es läuft gerade eine andere Platte. Beenden und diese starten?",
    "Artist":
        "Künstler",
    "Artist ignored by Last.fm":
        "Künstler von Last.fm ignoriert",
    "Cancel":
        "Abbrechen",
    "Cannot reach Discogs: {e}":
        "Keine Verbindung zu Discogs: {e}",
    "Cannot reach Last.fm: {e}":
        "Keine Verbindung zu Last.fm: {e}",
    "Checking token …":
        "Prüfe Token …",
    "Close":
        "Schließen",
    "Collection":
        "Sammlung",
    "Connect":
        "Verbinden",
    "Connecting …":
        "Verbinde …",
    "Create API account …":
        "API-Konto erstellen …",
    "Daily limit reached":
        "Tageslimit erreicht",
    "Discogs error {code}: {text}":
        "Discogs-Fehler {code}: {text}",
    "Discogs has no tracklist for this release.":
        "Discogs hat für diese Ausgabe keine Tracklist.",
    "Discogs is overloaded right now. Please try again later.":
        "Discogs ist gerade überlastet. Bitte später nochmal versuchen.",
    "Discogs not connected":
        "Discogs nicht verbunden",
    "Discogs rejected the token. Please enter it again in Settings.":
        "Discogs lehnt den Token ab. Bitte in den Einstellungen neu eintragen.",
    "Discogs: not connected":
        "Discogs: nicht verbunden",
    "Done – {n} track(s) scrobbled.":
        "Fertig – {n} Track(s) gescrobbelt.",
    "Double-click to change (m:ss). Leave empty = Discogs value.":
        "Doppelklick zum Ändern (m:ss). Leer lassen = Discogs-Wert.",
    "File (not encrypted)":
        "Datei (unverschlüsselt)",
    "Flip the record: side {side}":
        "Platte umdrehen: Seite {side}",
    "Follows the tracklist in real time and scrobbles each track when it ends":
        "Läuft im Takt der Tracklist mit und scrobbelt jeden Track, wenn er vorbei ist",
    "Get token …":
        "Token holen …",
    "Getting session …":
        "Hole Sitzung …",
    "History":
        "Verlauf",
    "Invalid API key. Please copy it again from the Last.fm page.":
        "API key ungültig. Bitte nochmal von der Last.fm-Seite kopieren.",
    "Just finished listening":
        "Gerade eben zu Ende gehört",
    "Language":
        "Sprache",
    "Last.fm has opened in your browser.\n\nLog in there and click “Yes, allow access”.\n\nThen click OK here.":
        "Im Browser hat sich Last.fm geöffnet.\n\nMelde dich dort an und klicke auf „Yes, allow access“.\n\nDanach hier auf OK klicken.",
    "Last.fm login":
        "Last.fm-Anmeldung",
    "Last.fm login expired – please log in again under “Settings …”.":
        "Last.fm-Anmeldung abgelaufen – bitte unter „Einstellungen …“ neu anmelden.",
    "Last.fm only accepts scrobbles from the last 14 days.":
        "Last.fm nimmt nur Scrobbles aus den letzten 14 Tagen an.",
    "Last.fm sent an invalid response (HTTP {code}).":
        "Last.fm antwortet nicht korrekt (HTTP {code}).",
    "Last.fm: not logged in":
        "Last.fm: nicht angemeldet",
    "Later":
        "Später",
    "Length":
        "Länge",
    "Length when Discogs has none:":
        "Länge, wenn Discogs keine kennt:",
    "Loading collection from Discogs …":
        "Lade Sammlung von Discogs …",
    "Loading collection from Discogs … page {page} of {pages}":
        "Lade Sammlung von Discogs … Seite {page} von {pages}",
    "Loading tracklist …":
        "Lade Tracklist …",
    "Log in to Last.fm":
        "Bei Last.fm anmelden",
    "Log out":
        "Abmelden",
    "Next up: {pos} “{title}” – click ▶ Continue once the needle is down":
        "Weiter mit {pos} „{title}“ – klick auf ▶ Weiter, sobald die Nadel aufliegt",
    "No collection loaded yet.\n\nConnect Discogs under “Settings …”.":
        "Noch keine Sammlung geladen.\n\nVerbinde Discogs unter „Einstellungen …“.",
    "None":
        "Keine",
    "Not connected":
        "Nicht verbunden",
    "Not found on Discogs (404).":
        "Bei Discogs nicht gefunden (404).",
    "Not logged in":
        "Nicht angemeldet",
    "Not logged in to Last.fm.":
        "Nicht bei Last.fm angemeldet.",
    "Note: Last.fm doesn’t allow deleting through its API. Remove wrong scrobbles on last.fm under “Library” → track → trash icon.":
        "Hinweis: Last.fm erlaubt kein Löschen über die Schnittstelle. Falsch gescrobbelte Tracks entfernst du auf last.fm unter „Library“ → Track → Papierkorb.",
    "Now Playing failed: {e}":
        "Now Playing fehlgeschlagen: {e}",
    "Open Last.fm profile":
        "Last.fm-Profil öffnen",
    "PAUSED":
        "PAUSIERT",
    "Pause at side changes in live mode (flip the record)":
        "Im Live-Modus beim Seitenwechsel anhalten (Platte umdrehen)",
    "Personal Discogs token":
        "Persönlicher Discogs-Token",
    "Please enter the API key and the shared secret.":
        "Bitte API key und Shared secret eintragen.",
    "Please paste the token first.":
        "Bitte zuerst den Token einfügen.",
    "Pos.":
        "Pos.",
    "Quit":
        "Beenden",
    "Recently added":
        "Zuletzt hinzugefügt",
    "Reload tracklist from Discogs":
        "Tracklist neu von Discogs laden",
    "Remove":
        "Entfernen",
    "Remove from history":
        "Aus dem Verlauf entfernen",
    "Remove {n} entry/entries from the local history?\n\n(They stay on Last.fm.)":
        "{n} Eintrag/Einträge aus dem lokalen Verlauf entfernen?\n\n(Auf Last.fm bleiben sie bestehen.)",
    "Removes the local entry only. Deleting on Last.fm is only possible on the website.":
        "Entfernt nur den lokalen Eintrag. Auf Last.fm löschen geht nur über die Website.",
    "Restart now":
        "Jetzt neu starten",
    "Scrobble the selected tracks afterwards":
        "Ausgewählte Tracks nachträglich scrobbeln",
    "Scrobble {n} tracks":
        "{n} Tracks scrobbeln",
    "Scrobbling":
        "Scrobbeln",
    "Search collection …  (artist, title, label, year, genre)":
        "Sammlung durchsuchen …  (Künstler, Titel, Label, Jahr, Genre)",
    "Secret Service (KWallet / GNOME Keyring)":
        "Secret Service (KWallet / Schlüsselbund)",
    "Select:":
        "Auswahl:",
    "Send album artist (helps with compilations)":
        "Album-Interpret mitsenden (hilft bei Samplern)",
    "Send pending now":
        "Ausstehende jetzt senden",
    "Set up accounts …":
        "Konten einrichten …",
    "Settings":
        "Einstellungen",
    "Settings …":
        "Einstellungen …",
    "Shared secret:":
        "Shared secret:",
    "Side {side}":
        "Seite {side}",
    "Sort:":
        "Sortieren:",
    "Started at:":
        "Angefangen um:",
    "Status":
        "Status",
    "Takes effect after a restart.":
        "Wird nach einem Neustart übernommen.",
    "The language will change after a restart. Restart Vinylogger now?":
        "Die Sprache wird nach einem Neustart umgestellt. Vinylogger jetzt neu starten?",
    "The shared secret doesn’t match the API key.":
        "Shared secret passt nicht zum API key.",
    "Time":
        "Zeit",
    "Timestamp is in the future":
        "Zeitpunkt liegt in der Zukunft",
    "Timestamp too far in the past (max. 14 days)":
        "Zeitpunkt zu weit in der Vergangenheit (max. 14 Tage)",
    "Tip: tick what you’re listening to. Lengths marked “~” are estimates – double-click a length to correct it.":
        "Tipp: Häkchen setzen, was du hörst. Längen mit „~“ sind geschätzt – Doppelklick auf die Länge, um sie zu korrigieren.",
    "Title":
        "Titel",
    "To get started, connect Discogs (for your collection) and log in to Last.fm.\n\nYou can also switch the language to German there.\n\nSet up now?":
        "Damit es losgehen kann, verbinde zuerst Discogs (für deine Sammlung) und melde dich bei Last.fm an.\n\nDort kannst du auch die Sprache umstellen.\n\nJetzt einrichten?",
    "Track ignored by Last.fm":
        "Titel von Last.fm ignoriert",
    "Unknown error":
        "Unbekannter Fehler",
    "Welcome":
        "Willkommen",
    "Windows Credential Manager":
        "Windows-Anmeldeinformationsverwaltung",
    "Year":
        "Jahr",
    "Your Discogs collection is empty.":
        "Deine Discogs-Sammlung ist leer.",
    "You’re not logged in to Last.fm yet.\n\nLog in now?":
        "Du bist noch nicht bei Last.fm angemeldet.\n\nJetzt anmelden?",
    "approx. ":
        "ca. ",
    "not listened long enough":
        "zu kurz gehört",
    "rejected (code {code})":
        "abgelehnt (Code {code})",
    "under 30 s, Last.fm won’t accept it":
        "unter 30 s, das nimmt Last.fm nicht an",
    "{artist} – {album}   ·   Track {n} of {total}":
        "{artist} – {album}   ·   Track {n} von {total}",
    "{n} of {total} tracks selected · {length}":
        "{n} von {total} Tracks ausgewählt · {length}",
    "{n} records loaded.":
        "{n} Platten geladen.",
    "{n} scrobble(s) saved – they’ll be sent once you’re logged in to Last.fm.":
        "{n} Scrobble(s) gespeichert – werden gesendet, sobald du bei Last.fm angemeldet bist.",
    "“{title}” not scrobbled – {why}.":
        "„{title}“ nicht gescrobbelt – {why}.",
    "← Pick a record from your collection":
        "← Wähle links eine Platte aus deiner Sammlung",
    "↻  Refresh collection":
        "↻  Sammlung aktualisieren",
    "⏭ Next":
        "⏭ Nächster",
    "⏳ Sending failed ({e}) – retrying in a few minutes.":
        "⏳ Senden fehlgeschlagen ({e}) – neuer Versuch in ein paar Minuten.",
    "⏳ pending":
        "⏳ ausstehend",
    "⏸ Pause":
        "⏸ Pause",
    "■ Stop":
        "■ Beenden",
    "▶  Listen now":
        "▶  Jetzt anhören",
    "▶ Continue":
        "▶ Weiter",
    "▶ Resume":
        "▶ Fortsetzen",
    "▶ {artist} – {title}: playing along. Each track is scrobbled when it ends.":
        "▶ {artist} – {title}: läuft mit. Jeder Track wird gescrobbelt, wenn er vorbei ist.",
    "⚠ No keyring found – credentials are stored unencrypted in a file only your user can read.":
        "⚠ Kein Schlüsselspeicher gefunden – Zugangsdaten liegen unverschlüsselt in einer Datei, die nur dein Benutzer lesen kann.",
    "✓  Already listened …":
        "✓  Schon gehört …",
    "✔ Connected as <b>{name}</b>":
        "✔ Verbunden als <b>{name}</b>",
    "✔ Logged in as <b>{name}</b>":
        "✔ Angemeldet als <b>{name}</b>",
    "✔ sent":
        "✔ gesendet",
    "✔ {n} track(s) scrobbled":
        "✔ {n} Track(s) gescrobbelt",
    "✖ rejected":
        "✖ abgelehnt",
    "🔒 Credentials are stored securely in: {where}":
        "🔒 Zugangsdaten werden sicher gespeichert in: {where}",
}
