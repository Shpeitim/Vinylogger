"""Where settings, database and covers live (Linux and Windows)."""
from __future__ import annotations

import os
from pathlib import Path

APP = "vinylogger"


def _base(win_env: str, xdg_env: str, xdg_default: Path) -> Path:
    if os.name == "nt":
        return Path(os.environ.get(win_env) or Path.home())
    return Path(os.environ.get(xdg_env) or xdg_default)


def config_dir() -> Path:
    d = _base("APPDATA", "XDG_CONFIG_HOME", Path.home() / ".config") / APP
    d.mkdir(parents=True, exist_ok=True)
    return d


def data_dir() -> Path:
    d = _base("LOCALAPPDATA", "XDG_DATA_HOME", Path.home() / ".local" / "share") / APP
    d.mkdir(parents=True, exist_ok=True)
    return d


def cover_dir() -> Path:
    d = data_dir() / "cover"
    d.mkdir(parents=True, exist_ok=True)
    return d
