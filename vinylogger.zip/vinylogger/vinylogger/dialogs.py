"""Dialogs: settings & accounts, scrobbling afterwards."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QDateTime, Qt, QTime, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDateTimeEdit, QDialog, QDialogButtonBox,
    QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPushButton,
    QRadioButton, QTableWidget, QTableWidgetItem, QTimeEdit, QVBoxLayout,
)

from .config import Settings
from .credentials import Credentials
from .discogs import Discogs, Track
from .i18n import LANGUAGES, _, fmt_dt, qt_datetime_format
from .lastfm import LastFm
from .workers import run_bg

DISCOGS_TOKEN_URL = "https://www.discogs.com/settings/developers"
LASTFM_CREATE_URL = "https://www.last.fm/api/account/create"


def fmt(sec: int | None) -> str:
    if not sec:
        return "?"
    sec = int(sec)
    return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}" if sec >= 3600 else f"{sec // 60}:{sec % 60:02d}"


def hint(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setWordWrap(True)
    lbl.setTextFormat(Qt.RichText)
    lbl.setOpenExternalLinks(True)
    f = lbl.font()
    f.setPointSizeF(f.pointSizeF() * 0.92)
    lbl.setFont(f)
    return lbl


class AccountsDialog(QDialog):
    """Language, Discogs token, Last.fm login and scrobble options."""

    def __init__(self, settings: Settings, creds: Credentials, parent=None):
        super().__init__(parent)
        self.settings, self.creds = settings, creds
        self.changed = False
        self.language_changed = False
        self.setWindowTitle(_("Settings"))
        self.setMinimumWidth(600)
        lay = QVBoxLayout(self)

        # ---------------- Language (always shown in both languages)
        g = QGroupBox("Language / Sprache")
        gl = QHBoxLayout(g)
        self.lang = QComboBox()
        for code, name in LANGUAGES:
            self.lang.addItem(name, code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(settings.language)))
        gl.addWidget(self.lang)
        gl.addWidget(hint(_("Takes effect after a restart.")), 1)
        lay.addWidget(g)

        # ---------------- Discogs
        g = QGroupBox("Discogs")
        gl = QVBoxLayout(g)
        gl.addWidget(hint(_(
            "1. Click “Get token …” – the Discogs developer settings open in your browser.<br>"
            "2. Click <b>“Generate new token”</b> there and copy the token.<br>"
            "3. Paste it here and click <b>Connect</b>.")))
        row = QHBoxLayout()
        self.dc_token = QLineEdit(creds.get("discogs_token") or "")
        self.dc_token.setEchoMode(QLineEdit.Password)
        self.dc_token.setPlaceholderText(_("Personal Discogs token"))
        btn_open = QPushButton(_("Get token …"))
        btn_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(DISCOGS_TOKEN_URL)))
        self.dc_connect = QPushButton(_("Connect"))
        self.dc_connect.clicked.connect(self.connect_discogs)
        row.addWidget(self.dc_token, 1)
        row.addWidget(btn_open)
        row.addWidget(self.dc_connect)
        gl.addLayout(row)
        self.dc_status = QLabel()
        gl.addWidget(self.dc_status)
        lay.addWidget(g)

        # ---------------- Last.fm
        g = QGroupBox("Last.fm")
        gl = QVBoxLayout(g)
        gl.addWidget(hint(_(
            "1. Create a free API account (button “Create API account …”). Enter e.g. <i>Vinylogger</i> "
            "as “Application name”, you can leave the other fields empty.<br>"
            "2. Copy the <b>API key</b> and <b>Shared secret</b> here.<br>"
            "3. Click <b>Log in to Last.fm</b> and allow access in your browser.")))
        form = QFormLayout()
        self.lf_key = QLineEdit(creds.get("lastfm_api_key") or "")
        self.lf_secret = QLineEdit(creds.get("lastfm_api_secret") or "")
        self.lf_secret.setEchoMode(QLineEdit.Password)
        form.addRow(_("API key:"), self.lf_key)
        form.addRow(_("Shared secret:"), self.lf_secret)
        gl.addLayout(form)
        row = QHBoxLayout()
        btn_create = QPushButton(_("Create API account …"))
        btn_create.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(LASTFM_CREATE_URL)))
        self.lf_login = QPushButton(_("Log in to Last.fm"))
        self.lf_login.clicked.connect(self.login_lastfm)
        self.lf_logout = QPushButton(_("Log out"))
        self.lf_logout.clicked.connect(self.logout_lastfm)
        row.addWidget(btn_create)
        row.addStretch(1)
        row.addWidget(self.lf_login)
        row.addWidget(self.lf_logout)
        gl.addLayout(row)
        self.lf_status = QLabel()
        gl.addWidget(self.lf_status)
        lay.addWidget(g)

        # ---------------- Scrobbling
        g = QGroupBox(_("Scrobbling"))
        form = QFormLayout(g)
        self.default_len = QTimeEdit()
        self.default_len.setDisplayFormat("m:ss")
        self.default_len.setTime(QTime(0, 0).addSecs(settings.default_track_seconds))
        form.addRow(_("Length when Discogs has none:"), self.default_len)
        self.album_artist = QCheckBox(_("Send album artist (helps with compilations)"))
        self.album_artist.setChecked(settings.send_album_artist)
        form.addRow(self.album_artist)
        self.side_pause = QCheckBox(_("Pause at side changes in live mode (flip the record)"))
        self.side_pause.setChecked(settings.pause_on_side_change)
        form.addRow(self.side_pause)
        lay.addWidget(g)

        safe = (_("🔒 Credentials are stored securely in: {where}", where=creds.backend) if creds.secure else
                _("⚠ No keyring found – credentials are stored unencrypted in a file only your user can read."))
        lay.addWidget(hint(safe))

        self._hints = self.findChildren(QLabel)

        btns = QDialogButtonBox(QDialogButtonBox.Close)
        btns.button(QDialogButtonBox.Close).setText(_("Close"))
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)
        self._refresh()

    # ------------------------------------------------------------ display
    def _fit_texts(self) -> None:
        """Wrapped labels sometimes get clipped by Qt – give them the height they need."""
        for lbl in self._hints:
            if lbl.wordWrap() and lbl.width() > 0:
                lbl.setMinimumHeight(lbl.heightForWidth(lbl.width()))

    def showEvent(self, e) -> None:
        super().showEvent(e)
        self._fit_texts()
        self.adjustSize()

    def resizeEvent(self, e) -> None:
        super().resizeEvent(e)
        self._fit_texts()

    def _refresh(self) -> None:
        if self.creds.get("discogs_token") and self.settings.discogs_username:
            self.dc_status.setText(_("✔ Connected as <b>{name}</b>", name=self.settings.discogs_username))
        else:
            self.dc_status.setText(_("Not connected"))
        if self.creds.get("lastfm_session") and self.settings.lastfm_username:
            self.lf_status.setText(_("✔ Logged in as <b>{name}</b>", name=self.settings.lastfm_username))
            self.lf_logout.setEnabled(True)
        else:
            self.lf_status.setText(_("Not logged in"))
            self.lf_logout.setEnabled(False)

    # ------------------------------------------------------------ Discogs
    def connect_discogs(self) -> None:
        token = self.dc_token.text().strip()
        if not token:
            QMessageBox.information(self, "Discogs", _("Please paste the token first."))
            return
        self.dc_connect.setEnabled(False)
        self.dc_status.setText(_("Checking token …"))

        def ok(username):
            self.creds.set("discogs_token", token)
            self.settings.discogs_username = username
            self.settings.save()
            self.changed = True
            self.dc_connect.setEnabled(True)
            self._refresh()

        def fail(e):
            self.dc_connect.setEnabled(True)
            self._refresh()
            QMessageBox.warning(self, "Discogs", str(e))

        run_bg(lambda: Discogs(token).identity(), on_done=ok, on_error=fail)

    # ------------------------------------------------------------ Last.fm
    def login_lastfm(self) -> None:
        key, secret = self.lf_key.text().strip(), self.lf_secret.text().strip()
        if not key or not secret:
            QMessageBox.information(self, "Last.fm", _("Please enter the API key and the shared secret."))
            return
        self.creds.set("lastfm_api_key", key)
        self.creds.set("lastfm_api_secret", secret)
        lf = LastFm(key, secret)
        self.lf_login.setEnabled(False)
        self.lf_status.setText(_("Connecting …"))

        def got_token(token):
            QDesktopServices.openUrl(QUrl(lf.auth_url(token)))
            QMessageBox.information(
                self, _("Last.fm login"),
                _("Last.fm has opened in your browser.\n\n"
                  "Log in there and click “Yes, allow access”.\n\n"
                  "Then click OK here."))
            self.lf_status.setText(_("Getting session …"))
            run_bg(lf.get_session, token, on_done=got_session, on_error=fail)

        def got_session(res):
            name, sk = res
            self.creds.set("lastfm_session", sk)
            self.settings.lastfm_username = name
            self.settings.save()
            self.changed = True
            self.lf_login.setEnabled(True)
            self._refresh()

        def fail(e):
            self.lf_login.setEnabled(True)
            self._refresh()
            code = getattr(e, "code", 0)
            msg = {
                14: _("Access hasn’t been allowed in the browser yet. Please try again."),
                10: _("Invalid API key. Please copy it again from the Last.fm page."),
                26: _("Invalid API key. Please copy it again from the Last.fm page."),
                13: _("The shared secret doesn’t match the API key."),
            }.get(code, str(e))
            QMessageBox.warning(self, "Last.fm", msg)

        run_bg(lf.get_token, on_done=got_token, on_error=fail)

    def logout_lastfm(self) -> None:
        self.creds.set("lastfm_session", None)
        self.settings.lastfm_username = None
        self.settings.save()
        self.changed = True
        self._refresh()

    def reject(self) -> None:
        s = self.settings
        t = self.default_len.time()
        secs = t.hour() * 3600 + t.minute() * 60 + t.second()
        if secs >= 30:
            s.default_track_seconds = secs
        s.send_album_artist = self.album_artist.isChecked()
        s.pause_on_side_change = self.side_pause.isChecked()
        new_lang = self.lang.currentData()
        if new_lang != s.language:
            s.language = new_lang
            self.language_changed = True
        s.save()
        super().reject()


class BackfillDialog(QDialog):
    """“Already listened”: scrobble the selected tracks afterwards with matching times."""

    def __init__(self, album_label: str, tracks: list[tuple[Track, int]], parent=None):
        super().__init__(parent)
        self.tracks = tracks
        self.total = sum(d for _t, d in tracks)
        self.setWindowTitle(_("Already listened – scrobble afterwards"))
        self.setMinimumSize(560, 460)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(_("<b>{album}</b><br>{n} tracks, {length} in total",
                               album=album_label, n=len(tracks), length=fmt(self.total))))

        self.rb_now = QRadioButton(_("Just finished listening"))
        self.rb_at = QRadioButton(_("Started at:"))
        grp = QButtonGroup(self)
        grp.addButton(self.rb_now)
        grp.addButton(self.rb_at)
        self.rb_now.setChecked(True)
        self.when = QDateTimeEdit(QDateTime.currentDateTime().addSecs(-self.total))
        self.when.setDisplayFormat(qt_datetime_format())
        self.when.setCalendarPopup(True)
        self.when.setMaximumDateTime(QDateTime.currentDateTime())
        self.when.setMinimumDateTime(QDateTime.currentDateTime().addDays(-14))
        row = QHBoxLayout()
        row.addWidget(self.rb_at)
        row.addWidget(self.when)
        row.addStretch(1)
        lay.addWidget(self.rb_now)
        lay.addLayout(row)
        lay.addWidget(hint(_("Last.fm only accepts scrobbles from the last 14 days.")))

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels([_("Time"), _("Title"), _("Length")])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        lay.addWidget(self.table, 1)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText(_("Scrobble {n} tracks", n=len(tracks)))
        btns.button(QDialogButtonBox.Cancel).setText(_("Cancel"))
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

        self.rb_now.toggled.connect(self._update)
        self.when.dateTimeChanged.connect(lambda *_a: self.rb_at.setChecked(True) or self._update())
        self._update()

    def start_ts(self) -> int:
        if self.rb_now.isChecked():
            return int(datetime.now().timestamp()) - self.total
        return int(self.when.dateTime().toSecsSinceEpoch())

    def timestamps(self) -> list[int]:
        ts, out = self.start_ts(), []
        for _t, d in self.tracks:
            out.append(ts)
            ts += d
        return out

    def _update(self) -> None:
        self.table.setRowCount(len(self.tracks))
        for r, ((t, d), ts) in enumerate(zip(self.tracks, self.timestamps())):
            vals = [fmt_dt(datetime.fromtimestamp(ts), short=True), f"{t.position}  {t.title}", fmt(d)]
            for c, txt in enumerate(vals):
                self.table.setItem(r, c, QTableWidgetItem(txt))
        self.table.resizeColumnToContents(0)
        self.table.resizeColumnToContents(2)
