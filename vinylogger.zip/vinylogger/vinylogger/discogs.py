"""Discogs: load the collection and tracklists (with a personal access token)."""
from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass

import requests

from . import __version__
from .i18n import _

API = "https://api.discogs.com"
USER_AGENT = f"Vinylogger/{__version__} (+private desktop app)"


class DiscogsError(Exception):
    pass


def clean_name(name: str) -> str:
    """'Prince (2)' -> 'Prince', 'Björk*' -> 'Björk'."""
    name = re.sub(r"\s\(\d+\)$", "", name.strip())
    return name.rstrip("*").strip()


def join_artists(artists: list[dict] | None) -> str:
    out = ""
    for a in artists or []:
        out += clean_name(a.get("name", ""))
        j = (a.get("join") or "").strip()
        if j:
            out += ", " if j == "," else f" {j} "
    out = out.strip().rstrip(",&").strip()
    return "Various Artists" if out.lower() == "various" else out


def parse_duration(text: str | None) -> int | None:
    if not text:
        return None
    parts = text.strip().split(":")
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None
    secs = 0
    for n in nums:
        secs = secs * 60 + n
    return secs or None


def side_of(position: str) -> str | None:
    """'A1' -> 'A', 'B' -> 'B', '2-3' -> 'CD 2', '5' -> None."""
    pos = position.strip()
    m = re.match(r"^([A-Za-z]{1,2})(?=\d|$|\.|-)", pos)
    if m and not pos.lower().startswith("cd"):
        return m.group(1).upper()
    m = re.match(r"^(?:CD)?(\d+)-\d+", pos, re.I)
    if m:
        return f"CD {m.group(1)}"
    return None


@dataclass
class Album:
    instance_id: int
    release_id: int
    artist: str
    title: str
    year: int | None
    thumb: str | None
    cover: str | None
    formats: str
    label: str
    catno: str
    genres: str
    date_added: str

    @property
    def search_text(self) -> str:
        return " ".join([self.artist, self.title, str(self.year or ""), self.label, self.catno,
                         self.genres, self.formats]).lower()

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Track:
    position: str
    title: str
    artist: str
    duration: int | None
    side: str | None

    def to_dict(self) -> dict:
        return asdict(self)


def album_from_item(item: dict) -> Album:
    b = item.get("basic_information") or {}
    formats = []
    for f in b.get("formats") or []:
        bits = [f.get("name", "")] + [d for d in (f.get("descriptions") or []) if d]
        qty = f.get("qty")
        txt = ", ".join(x for x in bits if x)
        if qty and str(qty) not in ("1", "0"):
            txt = f"{qty}× {txt}"
        formats.append(txt)
    labels = b.get("labels") or []
    year = b.get("year") or None
    return Album(
        instance_id=int(item.get("instance_id") or 0),
        release_id=int(b.get("id") or item.get("id")),
        artist=join_artists(b.get("artists")) or "?",
        title=b.get("title") or "?",
        year=int(year) if year else None,
        thumb=b.get("thumb") or None,
        cover=b.get("cover_image") or None,
        formats=" + ".join(formats),
        label=clean_name(labels[0].get("name", "")) if labels else "",
        catno=labels[0].get("catno", "") if labels else "",
        genres=", ".join((b.get("genres") or []) + (b.get("styles") or [])),
        date_added=item.get("date_added") or "",
    )


def parse_tracklist(release: dict) -> list[Track]:
    album_artist = join_artists(release.get("artists"))
    tracks: list[Track] = []

    def add(t: dict, prefix: str = "") -> None:
        title = (t.get("title") or "").strip()
        if not title:
            return
        artist = join_artists(t.get("artists")) or album_artist
        pos = (t.get("position") or "").strip()
        tracks.append(Track(pos, prefix + title, artist, parse_duration(t.get("duration")), side_of(pos)))

    for t in release.get("tracklist") or []:
        typ = t.get("type_", "track")
        if typ == "heading":
            continue
        if typ == "index" and t.get("sub_tracks"):
            for st in t["sub_tracks"]:
                add(st)
            continue
        add(t)
    return tracks


class Discogs:
    def __init__(self, token: str):
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": USER_AGENT, "Authorization": f"Discogs token={token}"})

    def _get(self, path: str, **params) -> dict:
        url = path if path.startswith("http") else API + path
        for attempt in range(5):
            try:
                r = self.s.get(url, params=params, timeout=30)
            except requests.RequestException as e:
                raise DiscogsError(_("Cannot reach Discogs: {e}", e=e)) from e
            if r.status_code == 429:  # too many requests -> wait a moment
                time.sleep(float(r.headers.get("Retry-After", 5 + attempt * 5)))
                continue
            if r.status_code == 401:
                raise DiscogsError(_("Discogs rejected the token. Please enter it again in Settings."))
            if r.status_code == 404:
                raise DiscogsError(_("Not found on Discogs (404)."))
            if not r.ok:
                raise DiscogsError(_("Discogs error {code}: {text}", code=r.status_code, text=r.text[:200]))
            # slow down gently before hitting the limit (60/min)
            if int(r.headers.get("X-Discogs-Ratelimit-Remaining", 10)) < 3:
                time.sleep(2)
            return r.json()
        raise DiscogsError(_("Discogs is overloaded right now. Please try again later."))

    def identity(self) -> str:
        return self._get("/oauth/identity")["username"]

    def collection(self, username: str, progress=None) -> list[Album]:
        albums: list[Album] = []
        page, pages = 1, 1
        while page <= pages:
            data = self._get(f"/users/{username}/collection/folders/0/releases",
                             per_page=100, page=page, sort="added", sort_order="desc")
            pages = int(data.get("pagination", {}).get("pages", 1)) or 1
            albums += [album_from_item(i) for i in data.get("releases", [])]
            if progress:
                progress((page, pages))
            page += 1
        return albums

    def release(self, release_id: int) -> dict:
        return self._get(f"/releases/{release_id}")

    def download(self, url: str) -> bytes:
        r = self.s.get(url, timeout=30, headers={"Authorization": None})
        r.raise_for_status()
        return r.content
