"""One-time import from the app's old name “Vinyl Scrobbler” (versions up to 1.2).

Copies settings, history, cached covers and stored credentials to the new
Vinylogger locations. The old files are left untouched.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

from .paths import _base, config_dir, data_dir

OLD = "vinyl" + "scrobbler"   # spelled this way so a search & replace never changes it
NEW = "vinylogger"
KEYS = ("discogs_token", "lastfm_api_key", "lastfm_api_secret", "lastfm_session")


def _old_config_dir() -> Path:
    return _base("APPDATA", "XDG_CONFIG_HOME", Path.home() / ".config") / OLD


def _old_data_dir() -> Path:
    return _base("LOCALAPPDATA", "XDG_DATA_HOME", Path.home() / ".local" / "share") / OLD


def _copy(src: Path, dst: Path) -> None:
    if src.exists() and not dst.exists():
        shutil.copy2(src, dst)


def _migrate_keyring() -> None:
    try:
        import keyring
        if os.name == "nt":
            from keyring.backends import Windows
            keyring.set_keyring(Windows.WinVaultKeyring())
        for key in KEYS:
            if keyring.get_password(NEW, key) is None:
                value = keyring.get_password(OLD, key)
                if value:
                    keyring.set_password(NEW, key, value)
    except Exception:  # noqa: BLE001  no keyring, locked wallet … – nothing to import then
        pass


def migrate() -> None:
    marker = config_dir() / ".imported-from-vinyl-scrobbler"
    if marker.exists():
        return
    old_cfg, old_data = _old_config_dir(), _old_data_dir()
    if old_cfg.is_dir() or old_data.is_dir():
        try:
            if old_cfg.is_dir():
                for name in ("einstellungen.json", "zugangsdaten.json"):
                    _copy(old_cfg / name, config_dir() / name)
            if old_data.is_dir():
                _copy(old_data / f"{OLD}.sqlite", data_dir() / f"{NEW}.sqlite")
                if (old_data / "cover").is_dir():
                    shutil.copytree(old_data / "cover", data_dir() / "cover", dirs_exist_ok=True)
            _migrate_keyring()
        except OSError:
            pass
    marker.write_text("1", encoding="utf-8")
