from vinylogger.app import main

main()
