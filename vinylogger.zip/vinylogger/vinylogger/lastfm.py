"""Last.fm API: login, “Now Playing” and scrobbling."""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass

import requests

from . import __version__
from .i18n import _

API = "https://ws.audioscrobbler.com/2.0/"
USER_AGENT = f"Vinylogger/{__version__}"


class LastFmError(Exception):
    def __init__(self, message: str, code: int = 0):
        super().__init__(message)
        self.code = code

    @property
    def needs_login(self) -> bool:
        return self.code in (4, 9, 14, 15)  # token/session invalid

    @property
    def temporary(self) -> bool:
        return self.code in (0, 8, 11, 16, 29)  # Netzwerk, Server, Limit


@dataclass
class Scrobble:
    artist: str
    track: str
    timestamp: int              # Startzeit, Unix-Sekunden (UTC)
    album: str | None = None
    album_artist: str | None = None
    duration: int | None = None

    def to_dict(self) -> dict:
        return asdict(self)


class LastFm:
    def __init__(self, api_key: str, api_secret: str, session_key: str | None = None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.session_key = session_key
        self.s = requests.Session()
        self.s.headers["User-Agent"] = USER_AGENT

    def _sign(self, params: dict) -> str:
        raw = "".join(k + params[k] for k in sorted(params) if k not in ("format", "callback"))
        return hashlib.md5((raw + self.api_secret).encode("utf-8")).hexdigest()

    def _call(self, method: str, session: bool = True, **params) -> dict:
        p = {"method": method, "api_key": self.api_key}
        p.update({k: str(v) for k, v in params.items() if v is not None and v != ""})
        if session:
            if not self.session_key:
                raise LastFmError(_("Not logged in to Last.fm."), 9)
            p["sk"] = self.session_key
        p["api_sig"] = self._sign(p)
        p["format"] = "json"
        try:
            r = self.s.post(API, data=p, timeout=30)
        except requests.RequestException as e:
            raise LastFmError(_("Cannot reach Last.fm: {e}", e=e), 0) from e
        try:
            data = r.json()
        except ValueError:
            raise LastFmError(_("Last.fm sent an invalid response (HTTP {code}).", code=r.status_code), 16)
        if "error" in data:
            raise LastFmError(data.get("message", _("Unknown error")), int(data["error"]))
        return data

    # ------------------------------------------------------------ Anmeldung
    def get_token(self) -> str:
        return self._call("auth.getToken", session=False)["token"]

    def auth_url(self, token: str) -> str:
        return f"https://www.last.fm/api/auth/?api_key={self.api_key}&token={token}"

    def get_session(self, token: str) -> tuple[str, str]:
        s = self._call("auth.getSession", session=False, token=token)["session"]
        self.session_key = s["key"]
        return s["name"], s["key"]

    # ------------------------------------------------------------ Scrobbeln
    def now_playing(self, s: Scrobble) -> None:
        self._call("track.updateNowPlaying", artist=s.artist, track=s.track, album=s.album,
                   albumArtist=s.album_artist, duration=s.duration)

    def scrobble(self, items: list[Scrobble]) -> list[tuple[bool, str]]:
        """Returns (accepted?, message) per item. Max. 50 per request."""
        results: list[tuple[bool, str]] = []
        for start in range(0, len(items), 50):
            batch = items[start:start + 50]
            params = {}
            for i, s in enumerate(batch):
                params[f"artist[{i}]"] = s.artist
                params[f"track[{i}]"] = s.track
                params[f"timestamp[{i}]"] = s.timestamp
                params[f"album[{i}]"] = s.album
                params[f"albumArtist[{i}]"] = s.album_artist
                params[f"duration[{i}]"] = s.duration
                params[f"chosenByUser[{i}]"] = 1
            data = self._call("track.scrobble", **params)
            entries = data.get("scrobbles", {}).get("scrobble", [])
            if isinstance(entries, dict):
                entries = [entries]
            for e in entries:
                ign = e.get("ignoredMessage") or {}
                code = str(ign.get("code", "0"))
                if code == "0":
                    results.append((True, ""))
                else:
                    reason = {
                        "1": _("Artist ignored by Last.fm"),
                        "2": _("Track ignored by Last.fm"),
                        "3": _("Timestamp too far in the past (max. 14 days)"),
                        "4": _("Timestamp is in the future"),
                        "5": _("Daily limit reached"),
                    }.get(code, ign.get("#text") or _("rejected (code {code})", code=code))
                    results.append((False, reason))
        return results
