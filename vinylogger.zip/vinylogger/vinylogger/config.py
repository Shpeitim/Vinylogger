"""Simple settings as JSON (no passwords – those live in credentials.py)."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields

from .paths import config_dir

FILE = config_dir() / "einstellungen.json"


@dataclass
class Settings:
    language: str = "en"                  # "en" or "de"
    default_track_seconds: int = 210      # when Discogs has no length
    send_album_artist: bool = True
    pause_on_side_change: bool = True     # pause at side changes in live mode
    discogs_username: str | None = None
    lastfm_username: str | None = None
    sort_mode: str = "artist"
    window_geometry: str | None = None
    splitter_state: str | None = None

    @classmethod
    def load(cls) -> "Settings":
        try:
            data = json.loads(FILE.read_text(encoding="utf-8"))
            known = {f.name for f in fields(cls)}
            return cls(**{k: v for k, v in data.items() if k in known})
        except (OSError, ValueError, TypeError):
            return cls()

    def save(self) -> None:
        FILE.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
