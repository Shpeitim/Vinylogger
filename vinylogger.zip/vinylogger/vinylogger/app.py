"""Main window: browse the collection, pick a record, scrobble."""
from __future__ import annotations

import os
import sys
import time
from datetime import datetime
from pathlib import Path

from PySide6 import QtSvg  # noqa: F401  (so SVG icons also work in the Windows .exe)
from PySide6.QtCore import (
    QLibraryInfo, QLocale, QProcess, QTranslator, QByteArray, QObject, QSize, QSortFilterProxyModel, Qt, QThreadPool, QTimer, QUrl, Signal,
)
from PySide6.QtGui import QAction, QDesktopServices, QFont, QIcon, QKeySequence, QPixmap, QStandardItem, QStandardItemModel
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QListView, QMainWindow, QMessageBox, QProgressBar, QPushButton, QSplitter, QStackedWidget,
    QTableWidget, QTableWidgetItem, QTabWidget, QToolButton, QVBoxLayout, QWidget, QFrame,
)

from . import __version__
from .config import Settings
from .credentials import Credentials
from .dialogs import AccountsDialog, BackfillDialog, fmt
from .discogs import Album, Discogs, Track, parse_tracklist
from .lastfm import LastFm, LastFmError, Scrobble
from .paths import cover_dir
from .i18n import _, fmt_dt, set_language
from .legacy import migrate
from .store import PENDING, REJECTED, SENT, Store
from .workers import run_bg

ICON = str(Path(__file__).with_name("icon.svg"))
ROLE_ALBUM = Qt.UserRole + 1
ROLE_SEARCH = Qt.UserRole + 2
ROLE_SORT = Qt.UserRole + 3

SORTS = [("artist", "Artist"), ("title", "Title"), ("added", "Recently added"), ("year", "Year")]


def parse_mmss(text: str) -> int | None:
    text = text.strip().lstrip("~")
    if not text:
        return None
    try:
        parts = [int(p) for p in text.split(":")]
    except ValueError:
        return None
    secs = 0
    for p in parts:
        secs = secs * 60 + p
    return secs if 0 < secs < 4 * 3600 else None


def artist_sort_key(name: str) -> str:
    n = name.lower()
    for art in ("the ", "die ", "der "):
        if n.startswith(art):
            return n[len(art):]
    return n


# ====================================================================== Cover
class CoverCache(QObject):
    """Downloads covers once and keeps them on disk."""

    ready = Signal(int, str, str)  # release_id, kind ('thumb'/'big'), pfad

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(4)
        self._busy: set[tuple[int, str]] = set()
        self.dl = Discogs("")  # only for downloads, needs no token

    def path(self, release_id: int, kind: str) -> Path:
        return cover_dir() / f"{release_id}_{kind}.jpg"

    def request(self, release_id: int, url: str | None, kind: str) -> str | None:
        p = self.path(release_id, kind)
        if p.exists():
            return str(p)
        if not url or (release_id, kind) in self._busy or "spacer.gif" in url:
            return None
        self._busy.add((release_id, kind))

        def fetch():
            data = self.dl.download(url)
            p.write_bytes(data)
            return str(p)

        def done(path):
            self._busy.discard((release_id, kind))
            self.ready.emit(release_id, kind, path)

        run_bg(fetch, on_done=done, on_error=lambda e: self._busy.discard((release_id, kind)), pool=self.pool)
        return None


# ====================================================================== Suche
class CollectionFilter(QSortFilterProxyModel):
    """All typed words must match (artist, title, label, year, genre …)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.words: list[str] = []
        self.setSortRole(ROLE_SORT)

    def set_query(self, text: str) -> None:
        self.words = text.lower().split()
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent) -> bool:
        if not self.words:
            return True
        text = self.sourceModel().index(row, 0, parent).data(ROLE_SEARCH) or ""
        return all(w in text for w in self.words)


# ====================================================================== Live-Modus
class LiveSession(QObject):
    """Follows the tracklist in real time: Now Playing, scrobble after each track."""

    changed = Signal()
    now_playing = Signal(object)            # Scrobble
    scrobble = Signal(object)               # Scrobble
    finished = Signal()
    note = Signal(str)

    def __init__(self, album: Album, tracks: list[tuple[Track, int]], settings: Settings, parent=None):
        super().__init__(parent)
        self.album, self.tracks, self.settings = album, tracks, settings
        self.index = 0
        self.elapsed = 0
        self.started_at = int(time.time())
        self.paused = False
        self.waiting_flip: str | None = None
        self.scrobbled = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

    @property
    def current(self) -> tuple[Track, int] | None:
        return self.tracks[self.index] if self.index < len(self.tracks) else None

    def _entry(self, t: Track, d: int, ts: int) -> Scrobble:
        return Scrobble(t.artist, t.title, ts, self.album.title,
                        self.album.artist if self.settings.send_album_artist else None, d)

    def start(self) -> None:
        self._begin_track()
        self.timer.start(1000)

    def _begin_track(self) -> None:
        self.elapsed = 0
        self.started_at = int(time.time())
        t, d = self.current
        self.now_playing.emit(self._entry(t, d, self.started_at))
        self.changed.emit()

    def _tick(self) -> None:
        if self.paused or not self.current:
            return
        self.elapsed += 1
        if self.elapsed >= self.current[1]:
            self._finish_track(natural=True)
        self.changed.emit()

    def _finish_track(self, natural: bool) -> None:
        t, d = self.current
        # Last.fm rule: at least 30 s, and half played or 4 minutes
        if self.elapsed >= 30 and (natural or self.elapsed >= min(d / 2, 240)):
            self.scrobble.emit(self._entry(t, d, self.started_at))
            self.scrobbled += 1
        else:
            why = _("under 30 s, Last.fm won’t accept it") if d < 30 else _("not listened long enough")
            self.note.emit(_("“{title}” not scrobbled – {why}.", title=t.title, why=why))
        prev_side = t.side
        self.index += 1
        if not self.current:
            self.stop()
            return
        nxt = self.current[0]
        if self.settings.pause_on_side_change and prev_side and nxt.side and nxt.side != prev_side:
            self.paused = True
            self.waiting_flip = nxt.side
            self.elapsed = 0
            self.changed.emit()
            return
        self._begin_track()

    def toggle_pause(self) -> None:
        if self.waiting_flip:
            self.waiting_flip = None
            self.paused = False
            self._begin_track()
            return
        self.paused = not self.paused
        self.changed.emit()

    def skip(self) -> None:
        if self.waiting_flip:
            self.toggle_pause()
            return
        if self.current:
            self._finish_track(natural=False)
            self.changed.emit()

    def stop(self) -> None:
        if self.timer.isActive():
            self.timer.stop()
            if self.current and not self.waiting_flip and self.elapsed >= 30:
                t, d = self.current
                if self.elapsed >= min(d / 2, 240):
                    self.scrobble.emit(self._entry(t, d, self.started_at))
                    self.scrobbled += 1
            self.finished.emit()


class NowPlayingBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        lay = QHBoxLayout(self)
        self.cover = QLabel()
        self.cover.setFixedSize(56, 56)
        self.cover.setScaledContents(True)
        lay.addWidget(self.cover)
        mid = QVBoxLayout()
        self.title = QLabel()
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(f.pointSizeF() * 1.1)
        self.title.setFont(f)
        self.sub = QLabel()
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setMaximumHeight(8)
        mid.addWidget(self.title)
        mid.addWidget(self.sub)
        mid.addWidget(self.progress)
        lay.addLayout(mid, 1)
        self.time = QLabel()
        lay.addWidget(self.time)
        self.btn_pause = QPushButton(_("⏸ Pause"))
        self.btn_skip = QPushButton(_("⏭ Next"))
        self.btn_stop = QPushButton(_("■ Stop"))
        for b in (self.btn_pause, self.btn_skip, self.btn_stop):
            b.setMinimumHeight(36)
            lay.addWidget(b)
        self.hide()

    def show_session(self, s: LiveSession, cover: QPixmap | None) -> None:
        if cover:
            self.cover.setPixmap(cover)
        cur = s.current
        if not cur:
            return
        t, d = cur
        if s.waiting_flip:
            self.title.setText(_("Flip the record: side {side}", side=s.waiting_flip))
            self.sub.setText(_("Next up: {pos} “{title}” – click ▶ Continue once the needle is down",
                               pos=t.position, title=t.title))
            self.btn_pause.setText(_("▶ Continue"))
            self.progress.setValue(0)
            self.time.setText("")
            return
        self.title.setText(f"{t.position}  {t.title}")
        self.sub.setText(_("{artist} – {album}   ·   Track {n} of {total}", artist=t.artist, album=s.album.title,
                           n=s.index + 1, total=len(s.tracks)) + ("   ·   " + _("PAUSED") if s.paused else ""))
        self.progress.setMaximum(max(d, 1))
        self.progress.setValue(min(s.elapsed, d))
        self.time.setText(f"{fmt(s.elapsed) if s.elapsed else '0:00'} / {fmt(d)}")
        self.btn_pause.setText(_("▶ Resume") if s.paused else _("⏸ Pause"))


# ====================================================================== Album-Ansicht
class AlbumPanel(QWidget):
    live_requested = Signal()
    backfill_requested = Signal()
    reload_requested = Signal()

    COVER = 240

    def __init__(self, parent=None):
        super().__init__(parent)
        self.album: Album | None = None
        self.tracks: list[Track] = []
        self.overrides: dict[str, int] = {}
        self.default_len = 210
        self._filling = False
        self.on_duration_edited = None  # callback(position, seconds|None)

        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cover = QLabel()
        self.cover.setFixedSize(self.COVER, self.COVER)
        self.cover.setAlignment(Qt.AlignCenter)
        top.addWidget(self.cover)
        info = QVBoxLayout()
        self.lbl_title = QLabel()
        f = QFont(self.font())
        f.setPointSizeF(f.pointSizeF() * 1.6)
        f.setBold(True)
        self.lbl_title.setFont(f)
        self.lbl_title.setWordWrap(True)
        self.lbl_artist = QLabel()
        fa = QFont(self.font())
        fa.setPointSizeF(fa.pointSizeF() * 1.25)
        self.lbl_artist.setFont(fa)
        self.lbl_artist.setWordWrap(True)
        self.lbl_meta = QLabel()
        self.lbl_meta.setWordWrap(True)
        self.lbl_meta.setEnabled(False)
        self.lbl_total = QLabel()
        info.addWidget(self.lbl_title)
        info.addWidget(self.lbl_artist)
        info.addWidget(self.lbl_meta)
        info.addStretch(1)
        info.addWidget(self.lbl_total)
        top.addLayout(info, 1)
        lay.addLayout(top)

        self.sides = QHBoxLayout()
        lay.addLayout(self.sides)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["", _("Pos."), _("Title"), _("Length")])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.itemChanged.connect(self._item_changed)
        lay.addWidget(self.table, 1)
        tip = QLabel(_("Tip: tick what you’re listening to. Lengths marked “~” are estimates – "
                       "double-click a length to correct it."))
        tip.setWordWrap(True)
        tip.setEnabled(False)
        lay.addWidget(tip)

        btns = QHBoxLayout()
        self.btn_reload = QToolButton()
        self.btn_reload.setText("↻")
        self.btn_reload.setToolTip(_("Reload tracklist from Discogs"))
        self.btn_reload.clicked.connect(self.reload_requested)
        self.btn_backfill = QPushButton(_("✓  Already listened …"))
        self.btn_backfill.setToolTip(_("Scrobble the selected tracks afterwards"))
        self.btn_backfill.clicked.connect(self.backfill_requested)
        self.btn_live = QPushButton(_("▶  Listen now"))
        self.btn_live.setToolTip(_("Follows the tracklist in real time and scrobbles each track when it ends"))
        fb = QFont(self.font())
        fb.setBold(True)
        fb.setPointSizeF(fb.pointSizeF() * 1.1)
        self.btn_live.setFont(fb)
        for b in (self.btn_backfill, self.btn_live):
            b.setMinimumHeight(42)
        self.btn_live.clicked.connect(self.live_requested)
        btns.addWidget(self.btn_reload)
        btns.addStretch(1)
        btns.addWidget(self.btn_backfill)
        btns.addWidget(self.btn_live)
        lay.addLayout(btns)

    # ------------------------------------------------------------ fill
    def show_album(self, a: Album, cover: QPixmap | None) -> None:
        self.album = a
        self.lbl_title.setText(a.title)
        self.lbl_artist.setText(a.artist)
        meta = " · ".join(x for x in [str(a.year) if a.year else "", a.formats,
                                      f"{a.label} {a.catno}".strip(), a.genres] if x)
        self.lbl_meta.setText(meta)
        self.set_cover(cover)
        self.set_tracks([], {}, loading=True)

    def set_cover(self, pm: QPixmap | None) -> None:
        if pm and not pm.isNull():
            self.cover.setPixmap(pm.scaled(self.COVER, self.COVER, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            self.cover.setPixmap(QIcon(ICON).pixmap(QSize(self.COVER - 40, self.COVER - 40)))

    def set_tracks(self, tracks: list[Track], overrides: dict[str, int], loading=False, error: str = "") -> None:
        self.tracks, self.overrides = tracks, overrides
        self._filling = True
        self.table.setRowCount(len(tracks))
        multi_artist = len({t.artist for t in tracks}) > 1 or (self.album and any(
            t.artist != self.album.artist for t in tracks))
        for r, t in enumerate(tracks):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            chk.setCheckState(Qt.Checked)
            self.table.setItem(r, 0, chk)
            pos = QTableWidgetItem(t.position)
            pos.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, pos)
            title = f"{t.title}   —   {t.artist}" if multi_artist else t.title
            ti = QTableWidgetItem(title)
            ti.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 2, ti)
            self.table.setItem(r, 3, self._dur_item(t))
        self._filling = False
        self._build_side_buttons()
        if loading:
            self.lbl_total.setText(_("Loading tracklist …"))
        elif error:
            self.lbl_total.setText(f"⚠ {error}")
        elif not tracks:
            self.lbl_total.setText(_("Discogs has no tracklist for this release."))
        self._update_total()

    def _dur_item(self, t: Track) -> QTableWidgetItem:
        own = self.overrides.get(t.position)
        if own:
            it = QTableWidgetItem(fmt(own))
        elif t.duration:
            it = QTableWidgetItem(fmt(t.duration))
        else:
            it = QTableWidgetItem("~" + fmt(self.default_len))
            it.setForeground(self.palette().placeholderText())
            f = it.font()
            f.setItalic(True)
            it.setFont(f)
        it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        it.setToolTip(_("Double-click to change (m:ss). Leave empty = Discogs value."))
        return it

    def _build_side_buttons(self) -> None:
        while self.sides.count():
            w = self.sides.takeAt(0).widget()
            if w:
                w.deleteLater()
        if not self.tracks:
            return
        self.sides.addWidget(QLabel(_("Select:")))
        for label, fn in [(_("All"), lambda: self._check(lambda t: True)),
                          (_("None"), lambda: self._check(lambda t: False))]:
            b = QPushButton(label)
            b.clicked.connect(fn)
            self.sides.addWidget(b)
        seen = []
        for t in self.tracks:
            if t.side and t.side not in seen:
                seen.append(t.side)
        if len(seen) > 1:
            for side in seen:
                b = QPushButton(side if side.startswith("CD") else _("Side {side}", side=side))
                b.clicked.connect(lambda _=False, s=side: self._check(lambda t: t.side == s))
                self.sides.addWidget(b)
        self.sides.addStretch(1)

    def _check(self, pred) -> None:
        self._filling = True
        for r, t in enumerate(self.tracks):
            self.table.item(r, 0).setCheckState(Qt.Checked if pred(t) else Qt.Unchecked)
        self._filling = False
        self._update_total()

    def _item_changed(self, item: QTableWidgetItem) -> None:
        if self._filling:
            return
        if item.column() == 3:
            t = self.tracks[item.row()]
            secs = parse_mmss(item.text())
            if secs or not item.text().strip():
                if self.on_duration_edited:
                    self.on_duration_edited(t.position, secs)
                if secs:
                    self.overrides[t.position] = secs
                else:
                    self.overrides.pop(t.position, None)
            self._filling = True
            self.table.setItem(item.row(), 3, self._dur_item(t))
            self._filling = False
        self._update_total()

    def length_of(self, t: Track) -> int:
        return self.overrides.get(t.position) or t.duration or self.default_len

    def selected(self) -> list[tuple[Track, int]]:
        return [(t, self.length_of(t)) for r, t in enumerate(self.tracks)
                if self.table.item(r, 0) and self.table.item(r, 0).checkState() == Qt.Checked]

    def _update_total(self) -> None:
        sel = self.selected()
        has = bool(sel)
        self.btn_live.setEnabled(has)
        self.btn_backfill.setEnabled(has)
        if self.tracks:
            guessed = any(not (self.overrides.get(t.position) or t.duration) for t, _d in sel)
            self.lbl_total.setText(_("{n} of {total} tracks selected · {length}", n=len(sel), total=len(self.tracks),
                                     length=(_("approx. ") if guessed else "") + fmt(sum(d for _t, d in sel))))


# ====================================================================== Verlauf
class HistoryTab(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.win = win
        lay = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels([_("Time"), _("Artist"), _("Title"), _("Album"), _("Status")])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for c in (1, 2, 3):
            hh.setSectionResizeMode(c, QHeaderView.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        lay.addWidget(self.table, 1)
        row = QHBoxLayout()
        b_retry = QPushButton(_("Send pending now"))
        b_retry.clicked.connect(win.send_pending)
        b_del = QPushButton(_("Remove from history"))
        b_del.setToolTip(_("Removes the local entry only. Deleting on Last.fm is only possible on the website."))
        b_del.clicked.connect(self.delete_selected)
        b_web = QPushButton(_("Open Last.fm profile"))
        b_web.clicked.connect(self.open_web)
        row.addWidget(b_retry)
        row.addWidget(b_del)
        row.addStretch(1)
        row.addWidget(b_web)
        lay.addLayout(row)
        note = QLabel(_("Note: Last.fm doesn’t allow deleting through its API. Remove wrong scrobbles on last.fm "
                        "under “Library” → track → trash icon."))
        note.setWordWrap(True)
        note.setEnabled(False)
        lay.addWidget(note)

    def reload(self) -> None:
        entries = self.win.store.recent()
        self.table.setRowCount(len(entries))
        icons = {SENT: _("✔ sent"), PENDING: _("⏳ pending"), REJECTED: _("✖ rejected")}
        for r, e in enumerate(entries):
            s = e.scrobble
            vals = [fmt_dt(datetime.fromtimestamp(s.timestamp)), s.artist, s.track, s.album or "",
                    icons.get(e.status, e.status)]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if c == 0:
                    it.setData(Qt.UserRole, e.id)
                if c == 4 and e.message:
                    it.setToolTip(e.message)
                self.table.setItem(r, c, it)

    def delete_selected(self) -> None:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        if not rows:
            return
        if QMessageBox.question(self, _("Remove"), _("Remove {n} entry/entries from the local history?\n\n"
                                "(They stay on Last.fm.)", n=len(rows))) != QMessageBox.Yes:
            return
        for r in rows:
            self.win.store.delete(self.table.item(r, 0).data(Qt.UserRole))
        self.reload()

    def open_web(self) -> None:
        name = self.win.settings.lastfm_username
        QDesktopServices.openUrl(QUrl(f"https://www.last.fm/user/{name}/library" if name else "https://www.last.fm"))


# ====================================================================== Hauptfenster
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = Settings.load()
        self.creds = Credentials()
        self.store = Store()
        self.covers = CoverCache(self)
        self.covers.ready.connect(self._cover_ready)
        self.items_by_release: dict[int, list[QStandardItem]] = {}
        self.live: LiveSession | None = None
        self.discogs: Discogs | None = None
        self.lastfm: LastFm | None = None
        self._release_req = 0
        self._loading_collection = False
        self._in_flight: set[int] = set()
        self.restart_requested = False

        self.setWindowTitle("Vinylogger")
        self.setWindowIcon(QIcon(ICON))
        self.resize(1200, 800)
        self._init_clients()
        self._build_ui()
        if self.settings.window_geometry:
            self.restoreGeometry(QByteArray.fromBase64(self.settings.window_geometry.encode()))
        if self.settings.splitter_state:
            self.splitter.restoreState(QByteArray.fromBase64(self.settings.splitter_state.encode()))

        self.populate(self.store.load_collection())
        self.history.reload()
        self._update_account_status()
        if self.discogs and self.model.rowCount() == 0:
            QTimer.singleShot(300, self.refresh_collection)
        if not self.discogs or not self.lastfm or not self.lastfm.session_key:
            QTimer.singleShot(400, self._first_run_hint)

        self.retry_timer = QTimer(self)
        self.retry_timer.timeout.connect(self.send_pending)
        self.retry_timer.start(5 * 60 * 1000)
        QTimer.singleShot(2000, self.send_pending)

    # ------------------------------------------------------------ Konten
    def _init_clients(self) -> None:
        token = self.creds.get("discogs_token")
        self.discogs = Discogs(token) if token and self.settings.discogs_username else None
        key, secret = self.creds.get("lastfm_api_key"), self.creds.get("lastfm_api_secret")
        sk = self.creds.get("lastfm_session")
        self.lastfm = LastFm(key, secret, sk) if key and secret else None

    def _update_account_status(self) -> None:
        dc = f"Discogs: {self.settings.discogs_username}" if self.discogs else _("Discogs: not connected")
        lf = (f"Last.fm: {self.settings.lastfm_username}" if self.lastfm and self.lastfm.session_key
              else _("Last.fm: not logged in"))
        self.lbl_accounts.setText(f"{dc}   ·   {lf}")
        self.empty_stack.setCurrentIndex(1 if self.model.rowCount() else 0)

    def _first_run_hint(self) -> None:
        if QMessageBox.question(
                self, _("Welcome"),
                _("To get started, connect Discogs (for your collection) and log in to Last.fm.\n\n"
                  "You can also switch the language to German there.\n\nSet up now?")) == QMessageBox.Yes:
            self.open_accounts()

    def open_accounts(self) -> None:
        old_user = self.settings.discogs_username
        dlg = AccountsDialog(self.settings, self.creds, self)
        dlg.exec()
        self.settings = Settings.load()
        self._init_clients()
        if dlg.language_changed:
            box = QMessageBox(QMessageBox.Question, _("Language"),
                              _("The language will change after a restart. Restart Vinylogger now?"),
                              parent=self)
            yes = box.addButton(_("Restart now"), QMessageBox.AcceptRole)
            box.addButton(_("Later"), QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is yes:
                self.restart_requested = True
                QTimer.singleShot(0, self.close)
        self.panel.default_len = self.settings.default_track_seconds
        self._update_account_status()
        if dlg.changed and self.discogs and (self.model.rowCount() == 0 or old_user != self.settings.discogs_username):
            self.refresh_collection()
        if dlg.changed:
            self.send_pending()

    def require_lastfm(self) -> bool:
        if self.lastfm and self.lastfm.session_key:
            return True
        if QMessageBox.question(self, "Last.fm", _("You’re not logged in to Last.fm yet.\n\nLog in now?")) == QMessageBox.Yes:
            self.open_accounts()
        return bool(self.lastfm and self.lastfm.session_key)

    # ------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        tabs = QTabWidget()
        self.setCentralWidget(tabs)

        # --- Sammlung
        coll = QWidget()
        cl = QVBoxLayout(coll)
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText(_("Search collection …  (artist, title, label, year, genre)"))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda t: self.proxy.set_query(t))
        self.sort = QComboBox()
        for key, label in SORTS:
            self.sort.addItem(_(label), key)
        self.sort.setCurrentIndex(max(0, self.sort.findData(self.settings.sort_mode)))
        self.sort.currentIndexChanged.connect(self._apply_sort)
        self.btn_refresh = QPushButton(_("↻  Refresh collection"))
        self.btn_refresh.clicked.connect(self.refresh_collection)
        btn_acc = QPushButton(_("Settings …"))
        btn_acc.clicked.connect(self.open_accounts)
        bar.addWidget(self.search, 1)
        bar.addWidget(QLabel(_("Sort:")))
        bar.addWidget(self.sort)
        bar.addWidget(self.btn_refresh)
        bar.addWidget(btn_acc)
        cl.addLayout(bar)

        self.splitter = QSplitter(Qt.Horizontal)
        self.model = QStandardItemModel(self)
        self.proxy = CollectionFilter(self)
        self.proxy.setSourceModel(self.model)
        self.view = QListView()
        self.view.setModel(self.proxy)
        self.view.setViewMode(QListView.IconMode)
        self.view.setResizeMode(QListView.Adjust)
        self.view.setMovement(QListView.Static)
        self.view.setIconSize(QSize(150, 150))
        self.view.setGridSize(QSize(176, 214))
        self.view.setUniformItemSizes(True)
        self.view.setWordWrap(True)
        self.view.setTextElideMode(Qt.ElideRight)
        self.view.setSpacing(4)
        self.view.selectionModel().currentChanged.connect(self._album_selected)

        empty = QWidget()
        el = QVBoxLayout(empty)
        el.addStretch(1)
        self.lbl_empty = QLabel(_("No collection loaded yet.\n\nConnect Discogs under “Settings …”."))
        self.lbl_empty.setAlignment(Qt.AlignCenter)
        el.addWidget(self.lbl_empty)
        b = QPushButton(_("Set up accounts …"))
        b.clicked.connect(self.open_accounts)
        el.addWidget(b, 0, Qt.AlignCenter)
        el.addStretch(2)
        self.empty_stack = QStackedWidget()
        self.empty_stack.addWidget(empty)
        self.empty_stack.addWidget(self.view)
        self.splitter.addWidget(self.empty_stack)

        self.panel = AlbumPanel()
        self.panel.default_len = self.settings.default_track_seconds
        self.panel.on_duration_edited = self._duration_edited
        self.panel.live_requested.connect(self.start_live)
        self.panel.backfill_requested.connect(self.backfill)
        self.panel.reload_requested.connect(lambda: self.load_release(force=True))
        self.panel_stack = QStackedWidget()
        pick = QLabel(_("← Pick a record from your collection"))
        pick.setAlignment(Qt.AlignCenter)
        pick.setEnabled(False)
        self.panel_stack.addWidget(pick)
        self.panel_stack.addWidget(self.panel)
        self.splitter.addWidget(self.panel_stack)
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 2)
        self.splitter.setSizes([700, 500])
        cl.addWidget(self.splitter, 1)

        self.np_bar = NowPlayingBar()
        self.np_bar.btn_pause.clicked.connect(lambda: self.live and self.live.toggle_pause())
        self.np_bar.btn_skip.clicked.connect(lambda: self.live and self.live.skip())
        self.np_bar.btn_stop.clicked.connect(self.stop_live)
        cl.addWidget(self.np_bar)
        tabs.addTab(coll, _("Collection"))

        # --- Verlauf
        self.history = HistoryTab(self)
        tabs.addTab(self.history, _("History"))

        # --- Statusleiste
        self.lbl_accounts = QLabel()
        self.statusBar().addPermanentWidget(self.lbl_accounts)

        act = QAction(self)
        act.setShortcut(QKeySequence.Find)
        act.triggered.connect(lambda: (tabs.setCurrentIndex(0), self.search.setFocus(), self.search.selectAll()))
        self.addAction(act)

    def status(self, text: str, ms: int = 6000) -> None:
        self.statusBar().showMessage(text, ms)

    # ------------------------------------------------------------ Sammlung
    def refresh_collection(self) -> None:
        if not self.discogs or self._loading_collection:
            if not self.discogs:
                self.open_accounts()
            return
        self._loading_collection = True
        self.btn_refresh.setEnabled(False)
        self.status(_("Loading collection from Discogs …"), 0)

        def prog(p):
            page, pages = p
            self.status(_("Loading collection from Discogs … page {page} of {pages}", page=page, pages=pages), 0)

        def done(albums):
            self._loading_collection = False
            self.btn_refresh.setEnabled(True)
            self.store.save_collection(albums)
            self.populate(albums)
            self.status(_("{n} records loaded.", n=len(albums)))
            self._update_account_status()

        def fail(e):
            self._loading_collection = False
            self.btn_refresh.setEnabled(True)
            self.status("")
            QMessageBox.warning(self, "Discogs", str(e))

        run_bg(self.discogs.collection, self.settings.discogs_username,
               on_done=done, on_error=fail, on_progress=prog)

    def populate(self, albums: list[Album]) -> None:
        self.model.clear()
        self.items_by_release.clear()
        placeholder = QIcon(ICON)
        for a in albums:
            it = QStandardItem(f"{a.artist}\n{a.title}")
            it.setEditable(False)
            it.setData(a, ROLE_ALBUM)
            it.setData(a.search_text, ROLE_SEARCH)
            it.setToolTip(f"<b>{a.artist}</b><br>{a.title}<br>{a.year or ''} · {a.formats}")
            path = self.covers.request(a.release_id, a.thumb, "thumb")
            it.setIcon(QIcon(path) if path else placeholder)
            self.model.appendRow(it)
            self.items_by_release.setdefault(a.release_id, []).append(it)
        self._apply_sort()
        self.lbl_empty.setText(_("Your Discogs collection is empty.") if self.discogs and not albums
                               else _("No collection loaded yet.\n\nConnect Discogs under “Settings …”."))
        self.empty_stack.setCurrentIndex(1 if albums else 0)

    def _apply_sort(self) -> None:
        mode = self.sort.currentData()
        self.settings.sort_mode = mode
        for r in range(self.model.rowCount()):
            it = self.model.item(r)
            a: Album = it.data(ROLE_ALBUM)
            key = {
                "artist": f"{artist_sort_key(a.artist)}\t{a.year or 0:04d}\t{a.title.lower()}",
                "title": f"{a.title.lower()}\t{artist_sort_key(a.artist)}",
                "added": a.date_added,
                "year": f"{a.year or 9999:04d}\t{artist_sort_key(a.artist)}",
            }[mode]
            it.setData(key, ROLE_SORT)
        self.proxy.sort(0, Qt.DescendingOrder if mode == "added" else Qt.AscendingOrder)

    def _cover_ready(self, release_id: int, kind: str, path: str) -> None:
        if kind == "thumb":
            for it in self.items_by_release.get(release_id, []):
                it.setIcon(QIcon(path))
        elif self.panel.album and self.panel.album.release_id == release_id:
            self.panel.set_cover(QPixmap(path))

    def _album_selected(self, current, _prev) -> None:
        if not current.isValid():
            return
        a: Album = current.data(ROLE_ALBUM)
        self.panel_stack.setCurrentIndex(1)
        path = self.covers.request(a.release_id, a.cover, "big") or self.covers.request(a.release_id, a.thumb, "thumb")
        self.panel.show_album(a, QPixmap(path) if path else None)
        self.load_release()

    def load_release(self, force: bool = False) -> None:
        a = self.panel.album
        if not a:
            return
        self._release_req += 1
        req = self._release_req
        cached = None if force else self.store.get_release(a.release_id)
        overrides = self.store.durations(a.release_id)
        if cached:
            self.panel.set_tracks(parse_tracklist(cached), overrides)
            return
        if not self.discogs:
            self.panel.set_tracks([], overrides, error=_("Discogs not connected"))
            return
        self.panel.set_tracks([], overrides, loading=True)

        def done(data):
            self.store.save_release(a.release_id, data)
            if req == self._release_req:
                self.panel.set_tracks(parse_tracklist(data), overrides)

        def fail(e):
            if req == self._release_req:
                self.panel.set_tracks([], overrides, error=str(e))

        run_bg(self.discogs.release, a.release_id, on_done=done, on_error=fail)

    def _duration_edited(self, position: str, secs: int | None) -> None:
        if self.panel.album:
            self.store.set_duration(self.panel.album.release_id, position, secs)

    # ------------------------------------------------------------ Scrobbeln
    def _entries(self, tracks: list[tuple[Track, int]], stamps: list[int]) -> list[Scrobble]:
        a = self.panel.album
        aa = a.artist if self.settings.send_album_artist else None
        return [Scrobble(t.artist, t.title, ts, a.title, aa, d) for (t, d), ts in zip(tracks, stamps)]

    def submit(self, items: list[Scrobble], release_id: int | None) -> None:
        ids = self.store.add_scrobbles(items, release_id)
        self.history.reload()
        self._send(list(zip(ids, items)))

    def _send(self, pairs: list[tuple[int, Scrobble]]) -> None:
        pairs = [(i, s) for i, s in pairs if i not in self._in_flight]
        if not pairs or not (self.lastfm and self.lastfm.session_key):
            if pairs:
                self.status(_("{n} scrobble(s) saved – they’ll be sent once you’re logged in to Last.fm.", n=len(pairs)))
            return
        lf = self.lastfm
        self._in_flight.update(i for i, _s in pairs)

        def release():
            self._in_flight.difference_update(i for i, _s in pairs)

        def done(results):
            release()
            ok = 0
            for (log_id, _s), (accepted, msg) in zip(pairs, results):
                self.store.set_status(log_id, SENT if accepted else REJECTED, msg)
                ok += accepted
            self.history.reload()
            bad = len(pairs) - ok
            self.status(_("✔ {n} track(s) scrobbled", n=ok) + (_(", {n} rejected (see History)", n=bad) if bad else ""))

        def fail(e):
            release()
            for log_id, _s in pairs:
                self.store.set_status(log_id, PENDING, str(e))
            self.history.reload()
            if isinstance(e, LastFmError) and e.needs_login:
                self.status(_("Last.fm login expired – please log in again under “Settings …”."), 15000)
            else:
                self.status(_("⏳ Sending failed ({e}) – retrying in a few minutes.", e=e), 10000)

        run_bg(lf.scrobble, [s for _i, s in pairs], on_done=done, on_error=fail)

    def send_pending(self) -> None:
        entries = self.store.pending()
        if entries:
            self._send([(e.id, e.scrobble) for e in reversed(entries)])

    def backfill(self) -> None:
        sel = self.panel.selected()
        if not sel or not self.require_lastfm():
            return
        a = self.panel.album
        dlg = BackfillDialog(f"{a.artist} – {a.title}", sel, self)
        if dlg.exec():
            self.submit(self._entries(sel, dlg.timestamps()), a.release_id)

    # ------------------------------------------------------------ Live
    def start_live(self) -> None:
        sel = self.panel.selected()
        if not sel or not self.require_lastfm():
            return
        if self.live:
            if QMessageBox.question(self, _("Already playing"), _("Another record is playing right now. "
                                    "Stop it and start this one?")) != QMessageBox.Yes:
                return
            self.stop_live()
        a = self.panel.album
        self.live = LiveSession(a, sel, self.settings, self)
        self._live_cover = self.panel.cover.pixmap()
        self.live.changed.connect(lambda: self.live and self.np_bar.show_session(self.live, self._live_cover))
        self.live.now_playing.connect(self._send_now_playing)
        self.live.scrobble.connect(lambda s, rid=a.release_id: self.submit([s], rid))
        self.live.note.connect(self.status)
        self.live.finished.connect(self._live_finished)
        self.np_bar.show()
        self.live.start()
        self.status(_("▶ {artist} – {title}: playing along. Each track is scrobbled when it ends.", artist=a.artist, title=a.title))

    def _send_now_playing(self, s: Scrobble) -> None:
        if self.lastfm and self.lastfm.session_key:
            run_bg(self.lastfm.now_playing, s, on_error=lambda e: self.status(_("Now Playing failed: {e}", e=e)))

    def stop_live(self) -> None:
        if self.live:
            self.live.stop()

    def _live_finished(self) -> None:
        if self.live:
            n = self.live.scrobbled
            self.status(_("Done – {n} track(s) scrobbled.", n=n), 10000)
            self.live.deleteLater()
        self.live = None
        self.np_bar.hide()

    # ------------------------------------------------------------ Beenden
    def closeEvent(self, event) -> None:
        if self.live and not self.restart_requested and QMessageBox.question(
                self, _("Quit"), _("A record is playing in live mode. Quit anyway?\n\n"
                                   "The current track will be scrobbled if it has played long enough.")) != QMessageBox.Yes:
            event.ignore()
            return
        if self.live:
            self.live.stop()
        self.settings.window_geometry = bytes(self.saveGeometry().toBase64()).decode()
        self.settings.splitter_state = bytes(self.splitter.saveState().toBase64()).decode()
        self.settings.save()
        QThreadPool.globalInstance().waitForDone(5000)  # let running scrobbles finish
        super().closeEvent(event)


def main() -> None:
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("vinylogger.app")
        except Exception:  # noqa: BLE001
            pass
    migrate()  # take over settings, history and credentials from “Vinyl Scrobbler”
    app = QApplication(sys.argv)
    lang = Settings.load().language
    set_language(lang)
    locale = QLocale(QLocale.German, QLocale.Germany) if lang == "de" else QLocale(QLocale.English, QLocale.UnitedStates)
    QLocale.setDefault(locale)
    if lang == "de":  # Qt's own texts (Yes/No buttons, context menus) in German, if available
        qt_tr = QTranslator(app)
        if qt_tr.load(locale, "qtbase", "_", QLibraryInfo.path(QLibraryInfo.TranslationsPath)):
            app.installTranslator(qt_tr)
    app.setApplicationName("Vinylogger")
    app.setApplicationVersion(__version__)
    app.setDesktopFileName("vinylogger")
    app.setWindowIcon(QIcon(ICON))
    win = MainWindow()
    win.show()
    code = app.exec()
    if win.restart_requested:
        args = sys.argv[1:] if getattr(sys, "frozen", False) else sys.argv
        QProcess.startDetached(sys.executable, args)
    sys.exit(code)


if __name__ == "__main__":
    main()
